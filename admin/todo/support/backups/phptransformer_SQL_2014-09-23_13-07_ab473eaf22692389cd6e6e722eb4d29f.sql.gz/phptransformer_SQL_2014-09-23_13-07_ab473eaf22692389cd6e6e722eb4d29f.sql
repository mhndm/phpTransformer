#SKD101|phptransformer|70|2014.09.23 13:07:42|477|1|1|2|8|2|232|5|1|4|3|8|1|1|3|1|3|1|2|2|4|2|4|7|1|2|2|1|4|2|1|4|8|2|1|12|7|1|10|5|2|114

DROP TABLE IF EXISTS adminlog;
CREATE TABLE `adminlog` (
  `TryName` varchar(15) NOT NULL COMMENT 'الاسم المحاول الدخول فيه',
  `TryPassword` varchar(35) NOT NULL COMMENT 'كلمة سر المحاولة',
  `TryDate` datetime NOT NULL COMMENT 'الوقت حسب غريبتش',
  `tryIp` varchar(15) NOT NULL COMMENT 'رقم الايبي المحاول منه'
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS adminperm;
CREATE TABLE `adminperm` (
  `AdminID` varchar(11) NOT NULL COMMENT 'رقم المدير',
  `constName` varchar(100) NOT NULL COMMENT 'النوع قلب البرنامج او برنامج او بلوك',
  `varName` varchar(100) NOT NULL COMMENT 'اسم المتغير',
  `varValue` varchar(100) NOT NULL COMMENT 'قيمة المتغير',
  `perm` int(1) NOT NULL COMMENT 'له صلاحية'
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='جدول صلاحيات المدراء';

DROP TABLE IF EXISTS admins;
CREATE TABLE `admins` (
  `AdminId` varchar(11) NOT NULL COMMENT 'رقم المدير',
  `AdminMail` varchar(50) NOT NULL COMMENT 'بريد المدير',
  `LastLogin` datetime NOT NULL COMMENT 'اخر مرة سجل دخوله',
  `LastIp` varchar(15) NOT NULL COMMENT 'آخر ايبي دخل منه',
  `Note` text NOT NULL COMMENT 'ملاحظة المدير',
  `AdminSign` text NOT NULL COMMENT 'توقيع المدير في الرسائل',
  `BackupFolder` longtext NOT NULL COMMENT 'مجلد حفظ نسخ الاحتياط من قاعدة البيانات',
  `Stopped` datetime NOT NULL COMMENT 'تاريخ ايقافه',
  `IsAdam` int(1) NOT NULL COMMENT 'هل هو المدير العام',
  PRIMARY KEY (`AdminId`),
  UNIQUE KEY `AdminId` (`AdminId`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='جدول المدير';

INSERT INTO `admins` VALUES
('200700000-1', 'user@domain.com', '2014-09-23 11:07:50', '127.0.0.1', '', '', 'admin/todo/support/backups/', '0000-00-00 00:00:00', 1);

DROP TABLE IF EXISTS bancltrans;
CREATE TABLE `bancltrans` (
  `IdTrans` varchar(11) NOT NULL COMMENT 'رقم الحركة',
  `idBanClnt` varchar(11) NOT NULL COMMENT 'رقم المعلن',
  `Debit` double NOT NULL COMMENT 'مدين',
  `Credit` double NOT NULL COMMENT 'دائن',
  `Date` datetime NOT NULL COMMENT 'التاريخ',
  `ValueDate` datetime NOT NULL COMMENT 'تاريخ الاستحقاق',
  `Desc` varchar(100) NOT NULL COMMENT 'البيان',
  PRIMARY KEY (`IdTrans`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='حركة زبون الاعلان المتعلقة بالتح';

DROP TABLE IF EXISTS banner;
CREATE TABLE `banner` (
  `IdBanner` varchar(11) NOT NULL COMMENT 'رقم البانر',
  `IdComp` varchar(11) NOT NULL COMMENT 'رقم الحملة',
  `BanName` varchar(35) NOT NULL COMMENT 'اسم الاعلان',
  `ViewMade` double NOT NULL COMMENT 'عدد المشاهدات',
  `ClicksMade` double NOT NULL COMMENT 'عدد النقرات',
  `CodeBan` varchar(1024) NOT NULL COMMENT 'كود الاعلان',
  `ClickUrl` varchar(1024) NOT NULL COMMENT 'وجهة الاعلان',
  `altTxt` varchar(35) NOT NULL COMMENT 'النص الظاهر',
  `Position` varchar(1) NOT NULL COMMENT 'مكان الاعلان',
  `Active` varchar(1) NOT NULL COMMENT 'نشط نعم او لا او محذوف',
  `Cost` double NOT NULL COMMENT 'الكلفة الحالية للمعلن',
  UNIQUE KEY `IdBanner` (`IdBanner`),
  UNIQUE KEY `BanName` (`BanName`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='لاعلانات';

DROP TABLE IF EXISTS bannerclients;
CREATE TABLE `bannerclients` (
  `idBanClnt` varchar(11) NOT NULL COMMENT 'رقم زبون الاعلان',
  `UserId` varchar(11) NOT NULL COMMENT 'رقم المستخدم',
  `AdminOk` varchar(1) NOT NULL COMMENT 'تم الموافقة على حساب المعلن من قبل المدير نعم او لا',
  `adsPayment` varchar(20) NOT NULL COMMENT 'طريقة الدفع',
  UNIQUE KEY `idBanClnt` (`idBanClnt`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='المستخدمين المعلينين';

DROP TABLE IF EXISTS bannerplans;
CREATE TABLE `bannerplans` (
  `IdBanPlan` varchar(11) NOT NULL COMMENT 'رقم خطة الاعلان',
  `BPActive` varchar(1) NOT NULL COMMENT 'نشط نعم او لا',
  `BPName` varchar(15) NOT NULL COMMENT 'اسم الخطة',
  `BPDesc` varchar(35) NOT NULL COMMENT 'تفصيل الخطة',
  `ViewPrice` float NOT NULL COMMENT 'سعر المشاهدة',
  `ClickPrice` float NOT NULL COMMENT 'سعر النقرة',
  `LinksNbr` varchar(10) NOT NULL COMMENT 'عدد الارتباطات',
  `planStart` datetime NOT NULL COMMENT 'بداية العرض لهذه الخطة',
  `planEnd` datetime NOT NULL COMMENT 'نهاية العرض لهذه الخطة',
  UNIQUE KEY `IdBanPlan` (`IdBanPlan`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='خطط الاعلان';

DROP TABLE IF EXISTS bannerpositions;
CREATE TABLE `bannerpositions` (
  `IdBanPos` varchar(11) NOT NULL COMMENT 'رقم موضع الاعلان',
  `PositionNbr` varchar(2) NOT NULL COMMENT 'مكان الاعلان كرقم',
  `PositionName` varchar(15) NOT NULL COMMENT 'اسم الموضع',
  `PosWidth` varchar(11) NOT NULL COMMENT 'عرض مكان الاعلان',
  `PosHeight` varchar(11) NOT NULL COMMENT 'طول مكان الاعلان',
  UNIQUE KEY `IdBanPos` (`IdBanPos`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='مواضع الاعلانات في الموق';

INSERT INTO `bannerpositions` VALUES
('20070000001', '1', 'Ads Block', '160', '250');

DROP TABLE IF EXISTS blacklist;
CREATE TABLE `blacklist` (
  `BlackWord` varchar(100) NOT NULL COMMENT 'الكلمة المحظورة',
  `BlockReason` varchar(1024) NOT NULL COMMENT 'سبب الحظر',
  `BlockDate` datetime NOT NULL COMMENT 'تاريخ الحظر'
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='الكلمات المحظورة للاستعمال في ال';

DROP TABLE IF EXISTS blocklang;
CREATE TABLE `blocklang` (
  `idblocklang` varchar(11) NOT NULL COMMENT 'رقم الجدول',
  `BlockName` varchar(35) NOT NULL COMMENT 'اسم البلوك',
  `idLang` varchar(11) NOT NULL COMMENT 'رقم اللغة',
  `BlockTitle` varchar(35) NOT NULL COMMENT 'عنوان البلوك بهذه اللغة'
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `blocklang` VALUES
('20140000000', 'AccountBlock', '20070000001', 'شسيسشي س شي'),
('20140000001', 'AccountBlock', '20070000002', 'SSXCSCDD SD');

DROP TABLE IF EXISTS blocks;
CREATE TABLE `blocks` (
  `BlockName` varchar(35) NOT NULL DEFAULT '',
  `Active` varchar(1) NOT NULL COMMENT 'نشط نعم او لا',
  `View` varchar(1) NOT NULL COMMENT 'يمكن مشاهدته نعم او لا',
  `MainSec` varchar(2) NOT NULL COMMENT 'مكانه على اليمين او يسار',
  `Order` int(2) NOT NULL COMMENT 'ترتيبه من الاعلى',
  `ObjectId` varchar(11) NOT NULL COMMENT 'رقمه المرتبط بالسيكيوريتي',
  `Deleted` varchar(1) NOT NULL COMMENT 'هل البلوك محذوف؟',
  `License` text NOT NULL,
  `LastChekUpdate` datetime NOT NULL COMMENT 'آخر مرة تم فيها التحديث',
  `UpdateAvailble` float NOT NULL COMMENT 'رقم الاصدار المتوفر',
  `UpdateDesc` text NOT NULL COMMENT 'شرح التحديث الجديد',
  PRIMARY KEY (`BlockName`),
  UNIQUE KEY `BlockName` (`BlockName`),
  UNIQUE KEY `BlockName_2` (`BlockName`),
  UNIQUE KEY `BlockName_3` (`BlockName`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='البلوكات';

INSERT INTO `blocks` VALUES
('MainMenu', '1', '1', 'M', 1, '20070000001', '', '', '0000-00-00 00:00:00', '0', ''),
('AccountBlock', '1', '1', 'M', 8, '20070000002', '', '', '0000-00-00 00:00:00', '0', ''),
('Statistics', '1', '1', 'S', 2, '20070000003', '', '', '0000-00-00 00:00:00', '0', ''),
('Ads', '1', '1', 'M', 4, '20070000004', '', '', '0000-00-00 00:00:00', '0', ''),
('Gsearch', '1', '1', 'S', 1, '20070000005', '', '', '0000-00-00 00:00:00', '0', ''),
('Language', '1', '1', 'M', 2, '20070000006', '', '', '0000-00-00 00:00:00', '0', ''),
('Pool', '1', '1', 'S', 3, '20070000008', '', '', '0000-00-00 00:00:00', '0', ''),
('FreeBlock', '1', '1', 'M', 3, '20110000002', '0', '', '0000-00-00 00:00:00', '0', '');

DROP TABLE IF EXISTS campaign;
CREATE TABLE `campaign` (
  `IdComp` varchar(11) NOT NULL COMMENT 'ؤقم الحملة الاعلانية',
  `idBanClnt` varchar(11) NOT NULL COMMENT 'رقم الزبون',
  `CampName` varchar(35) NOT NULL COMMENT 'اسم الحملة الاعلانية',
  `CompStart` datetime NOT NULL COMMENT 'تاريخ بدء الحملة',
  `CompEnd` datetime NOT NULL COMMENT 'تاريخ نهاية الحملة',
  `MaxView` double NOT NULL COMMENT 'العدد الاقصى للمشاهدات',
  `MaxClick` double NOT NULL COMMENT 'العدد الاقصى للنقر',
  `Activity` varchar(1) NOT NULL COMMENT 'نشط او لا او محذوف',
  `Budget` double NOT NULL COMMENT 'الميزانية لهذه الحملة',
  UNIQUE KEY `IdComp` (`IdComp`),
  UNIQUE KEY `CampName` (`CampName`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='الحملات الاعلانية';

DROP TABLE IF EXISTS careers;
CREATE TABLE `careers` (
  `CvId` varchar(11) NOT NULL,
  `FirstNameValue` varchar(35) DEFAULT NULL,
  `FatherNameValue` varchar(35) DEFAULT NULL,
  `MotherNameValue` varchar(35) DEFAULT NULL,
  `GrandFatherNameValue` varchar(35) DEFAULT NULL,
  `FamilyNameValue` varchar(35) DEFAULT NULL,
  `BirthDateValue` varchar(35) DEFAULT NULL,
  `BirthLocationValue` varchar(35) DEFAULT NULL,
  `CertifecateFrom3Value` varchar(35) DEFAULT NULL,
  `SexValue` varchar(1) DEFAULT NULL,
  `NationalityValue` varchar(35) DEFAULT NULL,
  `SegelNbrValue` varchar(35) DEFAULT NULL,
  `SegelLocationValue` varchar(35) DEFAULT NULL,
  `DamanNbrValue` varchar(35) DEFAULT NULL,
  `celibateValue` varchar(35) DEFAULT NULL,
  `MariageValue` varchar(35) DEFAULT NULL,
  `WidowerValue` varchar(35) DEFAULT NULL,
  `DivorcedValue` varchar(35) DEFAULT NULL,
  `FianceValue` varchar(35) DEFAULT NULL,
  `SpendName1Value` varchar(35) DEFAULT NULL,
  `Relative1Value` varchar(35) DEFAULT NULL,
  `Sex1Value` varchar(1) DEFAULT NULL,
  `BirthDate1Value` varchar(35) DEFAULT NULL,
  `SpendName2Value` varchar(35) DEFAULT NULL,
  `Relative2Value` varchar(35) DEFAULT NULL,
  `Sex2Value` varchar(1) DEFAULT NULL,
  `BirthDate2Value` varchar(35) DEFAULT NULL,
  `SpendName3Value` varchar(35) DEFAULT NULL,
  `Relative3Value` varchar(35) DEFAULT NULL,
  `Sex3Value` varchar(1) DEFAULT NULL,
  `BirthDate3Value` varchar(35) DEFAULT NULL,
  `SpendName4Value` varchar(35) DEFAULT NULL,
  `Relative4Value` varchar(35) DEFAULT NULL,
  `Sex4Value` varchar(1) DEFAULT NULL,
  `BirthDate4Value` varchar(35) DEFAULT NULL,
  `SpendName5Value` varchar(35) DEFAULT NULL,
  `Sex5Value` varchar(1) DEFAULT NULL,
  `BirthDate5Value` varchar(35) DEFAULT NULL,
  `SpendName6Value` varchar(35) DEFAULT NULL,
  `Relative6Value` varchar(35) DEFAULT NULL,
  `Sex6Value` varchar(1) DEFAULT NULL,
  `BirthDate6Value` varchar(35) DEFAULT NULL,
  `HealthStatusValue` varchar(35) DEFAULT NULL,
  `HearingValue` varchar(1) DEFAULT NULL,
  `ViewingValue` varchar(1) DEFAULT NULL,
  `TalkingValue` varchar(1) DEFAULT NULL,
  `DidUSmokeYesValue` varchar(1) DEFAULT NULL,
  `DidUSmokeNoValue` varchar(1) DEFAULT NULL,
  `DidUDoObligingYesValue` varchar(1) DEFAULT NULL,
  `DidUDoObligingNoValue` varchar(1) DEFAULT NULL,
  `ObligingOtherValue` varchar(35) DEFAULT NULL,
  `TownValue` varchar(35) DEFAULT NULL,
  `RueValue` varchar(35) DEFAULT NULL,
  `BuildingValue` varchar(35) DEFAULT NULL,
  `BuildOwnerValue` varchar(35) DEFAULT NULL,
  `PhoneValue` varchar(35) DEFAULT NULL,
  `CellulaireValue` varchar(35) DEFAULT NULL,
  `EmailValue` varchar(35) DEFAULT NULL,
  `EducationLevel1Value` varchar(35) DEFAULT NULL,
  `Average1Value` varchar(35) DEFAULT NULL,
  `CertifecateFrom1Value` varchar(35) DEFAULT NULL,
  `CertifecateYear1Value` varchar(35) DEFAULT NULL,
  `EducationLevel2Value` varchar(35) DEFAULT NULL,
  `Average2Value` varchar(35) DEFAULT NULL,
  `CertifecateFrom2Value` varchar(35) DEFAULT NULL,
  `CertifecateYear2Value` varchar(35) DEFAULT NULL,
  `EducationLevel3Value` varchar(35) DEFAULT NULL,
  `Average3Value` varchar(35) DEFAULT NULL,
  `CertifecateFrom3` varchar(35) DEFAULT NULL,
  `CertifecateYear3Value` varchar(35) DEFAULT NULL,
  `EducationLevel4Value` varchar(35) DEFAULT NULL,
  `Average14Value` varchar(35) DEFAULT NULL,
  `CertifecateFrom14Value` varchar(35) DEFAULT NULL,
  `CertifecateYear4Value` varchar(35) DEFAULT NULL,
  `EducationLevel5Value` varchar(35) DEFAULT NULL,
  `Average5Value` varchar(35) DEFAULT NULL,
  `CertifecateFrom5Value` varchar(35) DEFAULT NULL,
  `CertifecateYear5Value` varchar(35) DEFAULT NULL,
  `CycleName1Value` varchar(35) DEFAULT NULL,
  `SkillsFromCycle1Value` varchar(35) DEFAULT NULL,
  `CycleFrom1Value` varchar(35) DEFAULT NULL,
  `CycleDate1Value` varchar(35) DEFAULT NULL,
  `CycleName2Value` varchar(35) DEFAULT NULL,
  `CycleInterval2Value` varchar(35) DEFAULT NULL,
  `SkillsFromCycle12Value` varchar(35) DEFAULT NULL,
  `CycleFrom2Value` varchar(35) DEFAULT NULL,
  `CycleName3Value` varchar(35) DEFAULT NULL,
  `CycleInterval3Value` varchar(35) DEFAULT NULL,
  `CycleDate2Value` varchar(35) DEFAULT NULL,
  `CycleInterval1Value` varchar(35) DEFAULT NULL,
  `SkillsFromCycle13Value` varchar(35) DEFAULT NULL,
  `CycleFrom3Value` varchar(35) DEFAULT NULL,
  `CycleDate3Value` varchar(35) DEFAULT NULL,
  `CycleName4Value` varchar(35) DEFAULT NULL,
  `CycleInterval4Value` varchar(35) DEFAULT NULL,
  `SkillsFromCycle14Value` varchar(35) DEFAULT NULL,
  `CycleFrom4Value` varchar(35) DEFAULT NULL,
  `CycleDate4Value` varchar(35) DEFAULT NULL,
  `CycleName5Value` varchar(35) DEFAULT NULL,
  `CycleInterval5Value` varchar(35) DEFAULT NULL,
  `SkillsFromCycle15Value` varchar(35) DEFAULT NULL,
  `CycleFrom5Value` varchar(35) DEFAULT NULL,
  `CycleDate5Value` varchar(35) DEFAULT NULL,
  `LangName1Value` varchar(35) DEFAULT NULL,
  `ReadExcellent1Value` varchar(1) DEFAULT NULL,
  `ReadGood1Value` varchar(1) DEFAULT NULL,
  `ReadMoyen1Value` varchar(1) DEFAULT NULL,
  `ReadUnderMoyen1Value` varchar(1) DEFAULT NULL,
  `WriteExcellent1Value` varchar(1) DEFAULT NULL,
  `WriteGood1Value` varchar(1) DEFAULT NULL,
  `WriteMoyen1Value` varchar(1) DEFAULT NULL,
  `WriteUnderMoyen1Value` varchar(1) DEFAULT NULL,
  `SpeakExcellent1Value` varchar(1) DEFAULT NULL,
  `SpeakGood1Value` varchar(1) DEFAULT NULL,
  `SpeakMoyen1Value` varchar(1) DEFAULT NULL,
  `SpeakUnderMoyen1Value` varchar(1) DEFAULT NULL,
  `LangName2Value` varchar(35) DEFAULT NULL,
  `ReadExcellent2Value` varchar(1) DEFAULT NULL,
  `ReadGood2Value` varchar(1) DEFAULT NULL,
  `ReadMoyen2Value` varchar(1) DEFAULT NULL,
  `ReadUnderMoyen2Value` varchar(1) DEFAULT NULL,
  `WriteGood2Value` varchar(1) DEFAULT NULL,
  `WriteMoyen2Value` varchar(1) DEFAULT NULL,
  `WriteUnderMoyen2Value` varchar(1) DEFAULT NULL,
  `SpeakExcellent2Value` varchar(1) DEFAULT NULL,
  `SpeakGood2Value` varchar(1) DEFAULT NULL,
  `SpeakMoyen2Value` varchar(1) DEFAULT NULL,
  `SpeakUnderMoyen2Value` varchar(35) DEFAULT NULL,
  `LangName3Value` varchar(35) DEFAULT NULL,
  `ReadGood3Value` varchar(1) DEFAULT NULL,
  `ReadMoyen3Value` varchar(1) DEFAULT NULL,
  `ReadUnderMoyen3Value` varchar(1) DEFAULT NULL,
  `WriteExcellent3Value` varchar(1) DEFAULT NULL,
  `WriteGood3Value` varchar(1) DEFAULT NULL,
  `WriteMoyen3Value` varchar(1) DEFAULT NULL,
  `WriteUnderMoyen3Value` varchar(1) DEFAULT NULL,
  `SpeakExcellent3Value` varchar(1) DEFAULT NULL,
  `SpeakGood3Value` varchar(1) DEFAULT NULL,
  `SpeakMoyen3Value` varchar(1) DEFAULT NULL,
  `SpeakUnderMoyen3Value` varchar(1) DEFAULT NULL,
  `DontKnowValue` varchar(1) DEFAULT NULL,
  `DriverValue` varchar(1) DEFAULT NULL,
  `SupportValue` varchar(1) DEFAULT NULL,
  `ProgramerValue` varchar(1) DEFAULT NULL,
  `OtherExperienceValue` varchar(50) DEFAULT NULL,
  `CompName1Value` varchar(35) DEFAULT NULL,
  `ConctactMethode1Value` varchar(35) DEFAULT NULL,
  `FromDate1Value` varchar(35) DEFAULT NULL,
  `ToDate1Value` varchar(35) DEFAULT NULL,
  `OldJob1Value` varchar(35) DEFAULT NULL,
  `LastMonthSalary1Value` varchar(35) DEFAULT NULL,
  `WhyLeft1Value` varchar(35) DEFAULT NULL,
  `CompName2Value` varchar(35) DEFAULT NULL,
  `ConctactMethode2Value` varchar(35) DEFAULT NULL,
  `FromDate2Value` varchar(35) DEFAULT NULL,
  `ToDate2Value` varchar(35) DEFAULT NULL,
  `OldJob2Value` varchar(35) DEFAULT NULL,
  `LastMonthSalary2Value` varchar(35) DEFAULT NULL,
  `WhyLeft2Value` varchar(35) DEFAULT NULL,
  `CompName3Value` varchar(35) DEFAULT NULL,
  `ConctactMethode3Value` varchar(35) DEFAULT NULL,
  `FromDate3Value` varchar(35) DEFAULT NULL,
  `ToDate3Value` varchar(35) DEFAULT NULL,
  `OldJob3Value` varchar(35) DEFAULT NULL,
  `LastMonthSalary3Value` varchar(35) DEFAULT NULL,
  `WhyLeft3Value` varchar(35) DEFAULT NULL,
  `CompName4Value` varchar(35) DEFAULT NULL,
  `ConctactMethode4Value` varchar(35) DEFAULT NULL,
  `FromDate4Value` varchar(35) DEFAULT NULL,
  `ToDate4Value` varchar(35) DEFAULT NULL,
  `OldJob4Value` varchar(35) DEFAULT NULL,
  `LastMonthSalary4Value` varchar(35) DEFAULT NULL,
  `WhyLeft4Value` varchar(35) DEFAULT NULL,
  `CompName5Value` varchar(35) DEFAULT NULL,
  `ConctactMethode5Value` varchar(35) DEFAULT NULL,
  `FromDate5Value` varchar(35) DEFAULT NULL,
  `ToDate5Value` varchar(35) DEFAULT NULL,
  `OldJob5Value` varchar(35) DEFAULT NULL,
  `LastMonthSalary5Value` varchar(35) DEFAULT NULL,
  `WhyLeft5Value` varchar(35) DEFAULT NULL,
  `MustExcutingInOldJobsValue` varchar(100) DEFAULT NULL,
  `DiduDoAnotherJobsOverTimeValue` varchar(35) DEFAULT NULL,
  `DoYouRejectWorkOverTimeYesValue` varchar(1) DEFAULT NULL,
  `DoYouRejectWorkOverTimeNoValue` varchar(1) DEFAULT NULL,
  `DoYouRejectCallingOldJobValue` varchar(35) DEFAULT NULL,
  `HowDoYouHearAboutUsValue` varchar(35) DEFAULT NULL,
  `WhyYouWantToJoinValue` varchar(35) DEFAULT NULL,
  `WhatJobYouWichValue` varchar(35) DEFAULT NULL,
  `WhenUCanStartValue` varchar(35) DEFAULT NULL,
  `WishedSalaryValue` varchar(35) DEFAULT NULL,
  `TalkAboutSkillsInThisJobValue` varchar(50) DEFAULT NULL,
  `DidYouSendUsAnCVYesValue` varchar(1) DEFAULT NULL,
  `DidYouSendUsAnCVNoValue` varchar(1) DEFAULT NULL,
  `ifYesWriteCVNumberHereValue` varchar(35) DEFAULT NULL,
  `DoYouHaveNearbyInTheCompanyValue` varchar(50) DEFAULT NULL,
  `OutName1Value` varchar(35) DEFAULT NULL,
  `OutContact1Value` varchar(35) DEFAULT NULL,
  `OutJobDesc1Value` varchar(35) DEFAULT NULL,
  `OutName2Value` varchar(35) DEFAULT NULL,
  `OutContact2Value` varchar(35) DEFAULT NULL,
  `OutJobDesc2Value` varchar(35) DEFAULT NULL,
  `OutName3Value` varchar(35) DEFAULT NULL,
  `OutContact3Value` varchar(35) DEFAULT NULL,
  `OutJobDesc3Value` varchar(35) DEFAULT NULL,
  `TrueInfoValue` varchar(35) DEFAULT NULL,
  `WriteExcellent2Value` varchar(1) NOT NULL,
  `ReadExcellent3Value` varchar(1) NOT NULL,
  PRIMARY KEY (`CvId`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS categorie;
CREATE TABLE `categorie` (
  `IdCat` varchar(11) NOT NULL COMMENT 'رقم المجموعة',
  `ThemName` varchar(7) NOT NULL COMMENT 'اسم الشكل',
  PRIMARY KEY (`IdCat`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS catlang;
CREATE TABLE `catlang` (
  `IdCat` varchar(11) NOT NULL COMMENT 'رقم المجموعة',
  `IdLang` varchar(11) NOT NULL COMMENT 'رقم اللغة',
  `CatName` varchar(100) NOT NULL COMMENT 'اسم المجموعة',
  `Deleted` varchar(1) NOT NULL COMMENT 'هل نوع الخير محذوف',
  `sort` tinyint(1) NOT NULL COMMENT 'ترتيب المجموعة من فوق لتحت',
  PRIMARY KEY (`IdCat`,`IdLang`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `catlang` VALUES
('20100000000', '20070000001', 'أخبار عامة', '', 0),
('20100000000', '20070000002', 'Public News', '', 0);

DROP TABLE IF EXISTS cclang;
CREATE TABLE `cclang` (
  `cc` varchar(3) NOT NULL COMMENT 'كود البلد',
  `Contry` varchar(50) NOT NULL COMMENT 'اسم البلد',
  `Langcc` varchar(10) NOT NULL COMMENT 'لغة البلد',
  `rank` bigint(11) NOT NULL,
  `ccode` int(5) NOT NULL,
  PRIMARY KEY (`cc`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='لغة البلدان على اساس كود البلد';

INSERT INTO `cclang` VALUES
('AF', 'Afghanistan (افغانستان)', 'English', 1, 0),
('AL', 'Albania (Shqipëria)', 'English', 1, 0),
('DZ', 'Algeria (الجمهورية الجزائرية)', 'Arabic', 1, 0),
('AS', 'American Samoa', 'English', 1, 0),
('AD', 'Andorra', 'English', 1, 0),
('AO', 'Angola', 'English', 1, 0),
('AI', 'Anguilla', 'English', 1, 0),
('AQ', 'Antarctica', 'English', 1, 0),
('AG', 'Antigua and Barbuda', 'English', 1, 0),
('AR', 'Argentina', 'English', 1, 0),
('AM', 'Armenia ( Հայաստանի Հանրապետություն )', 'English', 1, 0),
('AW', 'Aruba', 'English', 1, 0),
('AP', 'Asia/Pacific Region', 'English', 1, 0),
('AU', 'Australia', 'English', 1, 0),
('AT', 'Austria (?sterreich)', 'English', 1, 0),
('AZ', 'Azerbaijan (Az?rbaycan)', 'English', 1, 0),
('BS', 'Bahamas', 'English', 1, 0),
('BH', 'Bahrain (بحرين)', 'Arabic', 1, 0),
('BD', 'Bangladesh  ( গণপ্রজাতন্ত্রী বাংলাদেশ )', 'English', 1, 0),
('BB', 'Barbados', 'English', 1, 0),
('BY', 'Belarus ( Рэспубліка Беларусь )', 'English', 1, 0),
('BE', 'Belgium (België)', 'English', 1, 0),
('BZ', 'Belize', 'English', 1, 0),
('BJ', 'Benin (Bénin)', 'English', 1, 0),
('BM', 'Bermuda', 'English', 1, 0),
('BT', 'Bhutan ( འབྲུག་རྒྱལ་ཁབ་ )', 'English', 1, 0),
('BO', 'Bolivia', 'English', 1, 0),
('BA', 'Bosnia and Herzegovina (Bosna i Hercegovina)', 'English', 1, 0),
('BW', 'Botswana', 'English', 1, 0),
('BR', 'Brazil (Brasil)', 'English', 1, 0),
('IO', 'British Indian Ocean Territory', 'English', 1, 0),
('BN', 'Brunei (Brunei Darussalam)', 'English', 1, 0),
('BG', 'Bulgaria ( Република България )', 'English', 1, 0),
('BF', 'Burkina Faso', 'English', 1, 0),
('BI', 'Burundi (Uburundi)', 'English', 1, 0),
('KH', 'Cambodia (Kampuchea)', 'English', 1, 0),
('CM', 'Cameroon (Cameroun)', 'English', 1, 0),
('CA', 'Canada', 'English', 1, 0),
('CV', 'Cape Verde (Cabo Verde)', 'English', 1, 0),
('KY', 'Cayman Islands', 'English', 1, 0),
('CF', 'Central African Republic (République Centrafricain', 'English', 1, 0),
('TD', 'Chad (Tchad)', 'English', 1, 0),
('CL', 'Chile', 'English', 1, 0),
('CN', 'China ( 中华人民共和国 )', 'English', 1, 0),
('CO', 'Colombia', 'English', 1, 0),
('KM', 'Comoros (Comores)', 'English', 1, 0),
('CG', 'Congo', 'English', 1, 0),
('CD', 'Congo, The Democratic Republic of the', 'English', 1, 0),
('CK', 'Cook Islands', 'English', 1, 0),
('CR', 'Costa Rica', 'English', 1, 0),
('CI', 'Côte D\'Ivoire', 'English', 1, 0),
('HR', 'Croatia (Hrvatska)', 'English', 1, 0),
('CU', 'Cuba', 'English', 1, 0),
('CY', 'Cyprus ( Κυπριακή Δημοκρατία )', 'English', 1, 0),
('CZ', 'Czech Republic (?esko)', 'English', 1, 0),
('DK', 'Denmark (Danmark)', 'English', 1, 0),
('DJ', 'Djibouti', 'English', 1, 0),
('DM', 'Dominica', 'English', 1, 0),
('DO', 'Dominican Republic', 'English', 1, 0),
('EC', 'Ecuador', 'English', 1, 0),
('EG', 'Egypt (مصر)', 'Arabic', 1, 0),
('SV', 'El Salvador', 'English', 1, 0),
('GQ', 'Equatorial Guinea (Guinea Ecuatorial)', 'English', 1, 0),
('ER', 'Eritrea (Ertra)', 'English', 1, 0),
('EE', 'Estonia (Eesti)', 'English', 1, 0),
('ET', 'Ethiopia ( ye-Ītyōṗṗyā )', 'English', 1, 0),
('EU', 'Europe', 'English', 1, 0),
('FK', 'Falkland Islands (Malvinas)', 'English', 1, 0),
('FO', 'Faroe Islands', 'English', 1, 0),
('FJ', 'Fiji', 'English', 1, 0),
('FI', 'Finland (Suomi)', 'English', 1, 0),
('FR', 'France', 'English', 1, 0),
('GF', 'French Guiana', 'English', 1, 0),
('PF', 'French Polynesia', 'English', 1, 0),
('GA', 'Gabon', 'English', 1, 0),
('GM', 'Gambia', 'English', 1, 0),
('GE', 'Georgia ( საქართველო )', 'English', 1, 0),
('DE', 'Germany (Deutschland)', 'English', 1, 0),
('GH', 'Ghana', 'English', 1, 0),
('GI', 'Gibraltar', 'English', 1, 0),
('GR', 'Greece ( Ελληνική Δημοκρατία )', 'English', 1, 0),
('GL', 'Greenland', 'English', 1, 0),
('GD', 'Grenada', 'English', 1, 0),
('GP', 'Guadeloupe', 'English', 1, 0),
('GU', 'Guam', 'English', 1, 0),
('GT', 'Guatemala', 'English', 1, 0),
('GN', 'Guinea (Guinée)', 'English', 1, 0),
('GW', 'Guinea-Bissau (Guiné-Bissau)', 'English', 1, 0),
('GY', 'Guyana', 'English', 1, 0),
('HT', 'Haiti (Haïti)', 'English', 1, 0),
('VA', 'Holy See (Vatican City State)', 'English', 1, 0),
('HN', 'Honduras', 'English', 1, 0),
('HK', 'Hong Kong', 'English', 1, 0),
('HU', 'Hungary (Magyarorsz?g)', 'English', 1, 0),
('IS', 'Iceland (?sland)', 'English', 1, 0),
('IN', 'India', 'English', 1, 0),
('ID', 'Indonesia', 'English', 1, 0),
('IR', 'Iran,  (الجمهورية الاسلامية في ايران)', 'Arabic', 1, 0),
('IQ', 'Iraq (العراق)', 'Arabic', 1, 0),
('IE', 'Ireland', 'English', 1, 0),
('IL', 'Other', 'English', 1, 0),
('IT', 'Italy (Italia)', 'English', 1, 0),
('JM', 'Jamaica', 'English', 1, 0),
('JP', 'Japan', 'English', 1, 0),
('JO', 'Jordan (الأردن)', 'Arabic', 1, 0),
('KZ', 'Kazakhstan ( قازاقستان )', 'English', 1, 0),
('KE', 'Kenya', 'English', 1, 0),
('KI', 'Kiribati', 'English', 1, 0),
('EH', 'Western Sahara (صحراوية)', 'English', 1, 0),
('KR', 'South Korea (??)', 'English', 1, 0),
('KW', 'Kuwait (الكويت)', 'Arabic', 1, 0),
('KG', 'Kyrgyzstan ( Кыргыз Республикасы )', 'English', 1, 0),
('LA', 'Lao People\'s Democratic Republic ( ສາທາລະນະລັດປະຊາ', 'English', 1, 0),
('LV', 'Latvia (Latvija)', 'English', 1, 0),
('LB', 'Lebanon (لبنان)', 'Arabic', 1, 0),
('LS', 'Lesotho', 'English', 1, 0),
('LR', 'Liberia', 'English', 1, 0),
('LY', 'Libyan Arab Jamahiriya (ليبيا)', 'Arabic', 1, 0),
('LI', 'Liechtenstein', 'English', 1, 0),
('LT', 'Lithuania (Lietuva)', 'English', 1, 0),
('LU', 'Luxembourg (Lëtzebuerg)', 'English', 1, 0),
('MO', 'Macau', 'English', 1, 0),
('MK', 'Macedonia ( Република Македонија )', 'English', 1, 0),
('MG', 'Madagascar (Madagasikara)', 'English', 1, 0),
('MW', 'Malawi', 'English', 1, 0),
('MY', 'Malaysia', 'English', 1, 0),
('MV', 'Maldives ( ދިވެހިރާއްޖޭގެ ޖުމްހޫރިއްޔާ )', 'English', 1, 0),
('ML', 'Mali', 'English', 1, 0),
('MT', 'Malta', 'English', 1, 0),
('MH', 'Marshall Islands', 'English', 1, 0),
('MQ', 'Martinique', 'English', 1, 0),
('MR', 'Mauritania (موريتانية)', 'Arabic', 1, 0),
('MU', 'Mauritius', 'English', 1, 0),
('YT', 'Mayotte', 'English', 1, 0),
('MX', 'Mexico (México)', 'English', 1, 0),
('FM', 'Micronesia, Federated States of', 'English', 1, 0),
('MD', 'Moldova, Republic of', 'English', 1, 0),
('MC', 'Monaco', 'English', 1, 0),
('MN', 'Mongolia ( Монгол улс )', 'English', 1, 0),
('ME', 'Montenegro ( Црна Гора )', 'English', 1, 0),
('MS', 'Montserrat', 'English', 1, 0),
('MA', 'Morocco (المغرب)', 'Arabic', 1, 0),
('MZ', 'Mozambique (Moçambique)', 'English', 1, 0),
('MM', 'Myanmar ( Pyidaunzu Thanmăda Myăma Nainngandaw)', 'English', 1, 0),
('NA', 'Namibia', 'English', 1, 0),
('NR', 'Nauru (Naoero)', 'English', 1, 0),
('NP', 'Nepal (  सङ्घीय लोकतान्त्रिक गणतन्त्र नेपाल )', 'English', 1, 0),
('NL', 'Netherlands (Nederland)', 'English', 1, 0),
('AN', 'Netherlands Antilles', 'English', 1, 0),
('NC', 'New Caledonia', 'English', 1, 0),
('NZ', 'New Zealand', 'English', 1, 0),
('NI', 'Nicaragua', 'English', 1, 0),
('NE', 'Niger', 'English', 1, 0),
('NG', 'Nigeria', 'English', 1, 0),
('NU', 'Niue', 'English', 1, 0),
('NF', 'Norfolk Island', 'English', 1, 0),
('MP', 'Northern Mariana Islands', 'English', 1, 0),
('NO', 'Norway (Norge)', 'English', 1, 0),
('OM', 'Oman (عمان)', 'Arabic', 1, 0),
('PK', 'Pakistan (پاکستان)', 'English', 1, 0),
('PW', 'Palau', 'English', 1, 0),
('PS', 'Other', 'English', 1, 0),
('PA', 'Panama ( República de Panamá )', 'English', 1, 0),
('PG', 'Papua New Guinea', 'English', 1, 0),
('PY', 'Paraguay', 'English', 1, 0),
('PE', 'Peru (Per?)', 'English', 1, 0),
('PH', 'Philippines (Pilipinas)', 'English', 1, 0),
('PL', 'Poland (Polska)', 'English', 1, 0),
('PT', 'Portugal', 'English', 1, 0),
('PR', 'Puerto Rico', 'English', 1, 0),
('QA', 'Qatar (قطر)', 'Arabic', 1, 0),
('RE', 'Reunion', 'English', 1, 0),
('RO', 'Romania (România)', 'English', 1, 0),
('RU', 'Russia ( Российская Федерация )', 'English', 1, 0),
('RW', 'Rwanda', 'English', 1, 0),
('KN', 'Saint Kitts and Nevis', 'English', 1, 0),
('LC', 'Saint Lucia', 'English', 1, 0),
('VC', 'Saint Vincent and the Grenadines', 'English', 1, 0),
('WS', 'Samoa', 'English', 1, 0),
('SM', 'San Marino', 'English', 1, 0),
('ST', 'Sao Tome and Principe', 'English', 1, 0),
('SA', 'Saudi Arabia (المملكة العربية السعودية)', 'Arabic', 1, 0),
('SN', 'Senegal (Sénégal)', 'English', 1, 0),
('RS', 'Serbia ( Република Србија )', 'English', 1, 0),
('SC', 'Seychelles', 'English', 1, 0),
('SL', 'Sierra Leone', 'English', 1, 0),
('SG', 'Singapore (Singapura)', 'English', 1, 0),
('SK', 'Slovakia (Slovensko)', 'English', 1, 0),
('SI', 'Slovenia (Slovenija)', 'English', 1, 0),
('SB', 'Solomon Islands', 'English', 1, 0),
('SO', 'Somalia (Soomaaliya)', 'English', 1, 0),
('ZA', 'South Africa', 'English', 1, 0),
('ES', 'Spain ( Reino de España )', 'English', 1, 0),
('LK', 'Sri Lanka', 'English', 1, 0),
('SD', 'Sudan (السودان)', 'Arabic', 1, 0),
('SR', 'Suriname', 'English', 1, 0),
('SZ', 'Swaziland', 'English', 1, 0),
('SE', 'Sweden (Sverige)', 'English', 1, 0),
('CH', 'Switzerland (Schweiz)', 'English', 1, 0),
('SY', 'Syria (سورية)', 'Arabic', 1, 0),
('TW', 'Taiwan ( 中華民國 )', 'English', 1, 0),
('TJ', 'Tajikistan ( Ҷумҳурии Тоҷикистон )', 'English', 1, 0),
('TZ', 'Tanzania, United Republic of', 'English', 1, 0),
('TH', 'Thailand ( ราชอาณาจักรไทย )', 'English', 1, 0),
('TG', 'Togo', 'English', 1, 0),
('TK', 'Tokelau', 'English', 1, 0),
('TO', 'Tonga', 'English', 1, 0),
('TT', 'Trinidad and Tobago', 'English', 1, 0),
('TN', 'Tunisia (تونس)', 'Arabic', 1, 0),
('TR', 'Turkey (Türkiye)', 'English', 1, 0),
('TM', 'Turkmenistan (Türkmenistan)', 'English', 1, 0),
('TC', 'Turks and Caicos Islands', 'English', 1, 0),
('TV', 'Tuvalu', 'English', 1, 0),
('UG', 'Uganda', 'English', 1, 0),
('UA', 'Ukraine ( Україна )', 'English', 1, 0),
('AE', 'United Arab Emirates (الإمارات العربية المتحدة)', 'English', 1, 0),
('GB', 'United Kingdom', 'English', 1, 0),
('US', 'United States', 'English', 1, 0),
('UM', 'United States Minor Outlying Islands', 'English', 1, 0),
('UY', 'Uruguay', 'English', 1, 0),
('UZ', 'Uzbekistan ( Ўзбекистон Республикаси )', 'English', 1, 0),
('VU', 'Vanuatu', 'English', 1, 0),
('VE', 'Venezuela', 'English', 1, 0),
('VN', 'Vietnam ( Cộng hòa xã hội chủ nghĩa Việt Nam )', 'English', 1, 0),
('VG', 'Virgin Islands, British', 'English', 1, 0),
('VI', 'Virgin Islands, U.S.', 'English', 1, 0),
('YE', 'Yemen (اليمن)', 'Arabic', 1, 0),
('ZM', 'Zambia', 'English', 1, 0),
('ZW', 'Zimbabwe', 'English', 1, 0),
('TL', 'East Timor (Timor-Leste)', 'English', 1, 0),
('KP', 'North Korea ( 조선민주주의인민공화국 )', 'English', 1, 0),
('XX', 'UnKnow', 'English', 1, 0);

DROP TABLE IF EXISTS contactus;
CREATE TABLE `contactus` (
  `IdDep` varchar(11) NOT NULL,
  `DepEmail` varchar(50) NOT NULL,
  PRIMARY KEY (`IdDep`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS contactuslang;
CREATE TABLE `contactuslang` (
  `IdDep` varchar(11) NOT NULL,
  `IdLang` varchar(11) NOT NULL,
  `DepName` varchar(128) NOT NULL
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS errlog;
CREATE TABLE `errlog` (
  `IdErr` double NOT NULL AUTO_INCREMENT COMMENT 'رقم الجدول',
  `errno` double NOT NULL COMMENT 'رقم الخطأ',
  `errmsg` longtext NOT NULL COMMENT 'رسالة الخطأ',
  `filename` longtext NOT NULL COMMENT 'اسم الملف',
  `linenum` double NOT NULL COMMENT 'رقم السطر',
  `DateErr` datetime NOT NULL COMMENT 'تاريخ الخطأ',
  PRIMARY KEY (`IdErr`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='جدول اخطاء البرنامج';

DROP TABLE IF EXISTS errpages;
CREATE TABLE `errpages` (
  `ErrNumber` varchar(4) NOT NULL COMMENT 'رقم صفحة الخطأ',
  `ErrPage` longtext NOT NULL COMMENT 'صفحة الخطأ',
  PRIMARY KEY (`ErrNumber`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='أخطاء المستخدم في طلب الموقع';

INSERT INTO `errpages` VALUES
('400', '<div align=\"center\"><font size=\"7\">400&nbsp;</font></div>'),
('401', '<div align=\"center\"><font size=\"7\">401</font></div>'),
('403', '<div align=\"center\"><font size=\"7\">403</font></div>'),
('404', '<div align=\"center\"><font size=\"7\">404</font> <br /></div>'),
('500', '<div align=\"center\"><font size=\"7\">500</font></div>');

DROP TABLE IF EXISTS externallinks;
CREATE TABLE `externallinks` (
  `Id` varchar(11) NOT NULL COMMENT 'رقم اللنك',
  `Link` text NOT NULL COMMENT 'عنوان اللنك',
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='الروابط الخارجية';

DROP TABLE IF EXISTS floodprotection;
CREATE TABLE `floodprotection` (
  `IP` varchar(32) NOT NULL COMMENT 'رقم ايبي المسجل للفلود',
  `TIME` varchar(22) /*!40101 CHARACTER SET latin1 */ /*!40101 COLLATE latin1_general_ci */ NOT NULL COMMENT 'الوقت للفلود'
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='من اجل الحماية من اللب الزائد على';

INSERT INTO `floodprotection` VALUES
(' 127.0.0.1', '1411473913.0397');

DROP TABLE IF EXISTS gallery;
CREATE TABLE `gallery` (
  `IdMedia` varchar(11) NOT NULL,
  `Path` text NOT NULL,
  `AddDate` datetime NOT NULL,
  `MapLocation` text NOT NULL,
  `MediaRank` varchar(11) NOT NULL,
  `MediaType` varchar(10) NOT NULL,
  `visible` int(1) NOT NULL COMMENT 'هل يستطيع مشاهدته الزوار',
  PRIMARY KEY (`IdMedia`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='جدول المكتبة';

INSERT INTO `gallery` VALUES
('20140000000', 'uploads/gallery/Albums/4b8bac0301.png', '2014-09-23 12:17:21', '', '', 'png', 1),
('20140000001', 'uploads/gallery/Albums/3178e6b667.jpg', '2014-09-23 12:19:33', '', '', 'jpg', 1),
('20140000002', 'uploads/gallery/Albums/22942b5ae7.png', '2014-09-23 12:19:34', '', '', 'png', 1),
('20140000003', 'uploads/gallery/Albums/d345061dd5.jpg', '2014-09-23 12:38:55', '', '', 'jpg', 1);

DROP TABLE IF EXISTS galleryfav;
CREATE TABLE `galleryfav` (
  `IdCmnt` varchar(11) NOT NULL,
  `IdMedia` varchar(11) NOT NULL,
  `UserId` varchar(11) NOT NULL,
  `Comment` text NOT NULL,
  `Date` datetime NOT NULL,
  PRIMARY KEY (`IdCmnt`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='تفضيلات و تعليقات الزوار';

INSERT INTO `galleryfav` VALUES
('20140000000', '20140000000', '20070000000', 'شيسش يشسي شسي سيس', '2014-09-23 12:47:20'),
('20140000001', '20140000000', '20070000000', 'ثقفقثف ثقفثق قث ء يسب بيسب سي يسب', '2014-09-23 12:48:34'),
('20140000002', '20140000001', '20070000000', 'safsadfsdfsdf', '2014-09-23 12:49:32');

DROP TABLE IF EXISTS gallerylang;
CREATE TABLE `gallerylang` (
  `IdMedia` varchar(11) NOT NULL,
  `IdLang` varchar(11) NOT NULL,
  `Caption` varchar(256) NOT NULL,
  `Desc` longtext NOT NULL,
  `Place` text NOT NULL,
  `Tags` text NOT NULL,
  PRIMARY KEY (`IdMedia`,`IdLang`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='لغة المكتبة';

INSERT INTO `gallerylang` VALUES
('20140000000', '20070000001', 'Screenshot from 2014-09-22 18:29:09', '', '', ''),
('20140000000', '20070000002', 'Screenshot from 2014-09-22 18:29:09', '', '', ''),
('20140000001', '20070000001', 'هذا عنوان الصورة', 'سيب سيب يسبسيب يسب يسب ي', 'بيروت', 'بيروت صورة مغلف'),
('20140000001', '20070000002', 'asds asa d', 'asd sad sad', 'dsaf sad', 'as d'),
('20140000002', '20070000001', '22942b5ae7', '', '', ''),
('20140000002', '20070000002', '22942b5ae7', '', '', ''),
('20140000003', '20070000001', 'd345061dd5', '', '', ''),
('20140000003', '20070000002', 'd345061dd5', '', '', '');

DROP TABLE IF EXISTS galleryparams;
CREATE TABLE `galleryparams` (
  `ThumbsWidth` int(11) NOT NULL,
  `ThumbsHeight` int(11) NOT NULL,
  `ColumsNbr` int(11) NOT NULL,
  `CellWidthMax` int(11) NOT NULL,
  `CellHeightMax` int(11) NOT NULL,
  `PrintFilenames` tinyint(1) NOT NULL
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='خصائص المعرض';

INSERT INTO `galleryparams` VALUES
(200, 200, 4, 200, 160, 1);

DROP TABLE IF EXISTS gballonlang;
CREATE TABLE `gballonlang` (
  `BallonId` bigint(20) NOT NULL COMMENT 'رقم البالون',
  `IdLang` varchar(11) NOT NULL COMMENT 'رقم اللغة',
  `BallonTitle` text NOT NULL COMMENT 'عنوان البالون',
  `BallonDesk` mediumtext NOT NULL COMMENT 'شرح البالون',
  PRIMARY KEY (`BallonId`,`IdLang`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='البالون حسب اللغة';

DROP TABLE IF EXISTS gballons;
CREATE TABLE `gballons` (
  `BallonId` bigint(20) NOT NULL COMMENT 'رقم البالون',
  `BallonX` double NOT NULL COMMENT 'مكان البالون X',
  `BallonY` double NOT NULL COMMENT 'مكان البالون Y',
  `BallonIcon` text NOT NULL COMMENT 'ايقونة البالون',
  `Deleted` varchar(1) NOT NULL COMMENT 'هل هو محذوف ؟',
  PRIMARY KEY (`BallonId`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='تحديد موقع على الخريطة';

DROP TABLE IF EXISTS googlemap;
CREATE TABLE `googlemap` (
  `key` text NOT NULL COMMENT 'كود جوجل',
  `MapWidth` int(11) NOT NULL COMMENT 'عرض الخريطة',
  `MapHeight` int(11) NOT NULL COMMENT 'طول الخريطة',
  `EarthX` double NOT NULL COMMENT 'مكان الخريطة x',
  `EarthY` double NOT NULL COMMENT 'مكان الخريطة y',
  `MapType` varchar(10) NOT NULL COMMENT 'نوع الخريطة',
  `Altitude` tinyint(4) NOT NULL COMMENT 'الارتفاع عن الارض بين 18 و 1'
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='خريطة جوجل';

INSERT INTO `googlemap` VALUES
('ABQIAAAAOA-7jCA1PY7HQKgVwPLXYBRi_j0U6kJrkFvY4-OX2XYmEAa76BTFPHZUW9AVP-svFJ8Gqx2ZkCdWQA', 600, 600, '33.896464', '36.049158', 'SATELLITE', 17);

DROP TABLE IF EXISTS groups;
CREATE TABLE `groups` (
  `GroupId` varchar(11) NOT NULL COMMENT 'رقم المجموعة',
  `GroupName` varchar(15) NOT NULL COMMENT 'اسم المجموعة',
  `Desc` varchar(50) NOT NULL COMMENT 'شرح المجموعة',
  `Deleted` varchar(1) NOT NULL COMMENT 'هل هو محذوف؟',
  UNIQUE KEY `GroupId` (`GroupId`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='مجموعات المستخدمين';

INSERT INTO `groups` VALUES
('20070000000', 'Guests', 'الزوار عادة يكون لهم صلاحية القراءة فقط', ''),
('20070000001', 'Users', 'المستخدمين المسجلين', ''),
('200700000-1', 'Admins', 'المدراء', '');

DROP TABLE IF EXISTS gsearch;
CREATE TABLE `gsearch` (
  `URL` varchar(7) NOT NULL COMMENT 'لون الرابط',
  `Border` varchar(7) NOT NULL COMMENT 'لون الحدود',
  `VisitedURL` varchar(7) NOT NULL COMMENT 'لون الروابط التي تم زيارتها',
  `Background` varchar(7) NOT NULL COMMENT 'لون الخلفية',
  `LogoBackground` varchar(7) NOT NULL COMMENT 'لون خلفية اللوغو',
  `Title` varchar(7) NOT NULL COMMENT 'لون العنوان',
  `Text` varchar(7) NOT NULL COMMENT 'لون النص',
  `LightURL` varchar(7) NOT NULL COMMENT 'لون الرابط الفاتح',
  `clientKey` varchar(50) NOT NULL COMMENT 'مفتاح رخصة الموقع',
  `target` varchar(15) NOT NULL COMMENT 'هل سيفتح بنفس المستعرض ؟'
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='البحث عبر خدمة جوجل';

INSERT INTO `gsearch` VALUES
('3399FF', '336699', '3399FE', 'F5F5F5', '06457a', '3399FF', '000000', '0000FF', 'pub-9756194919174825', 'google_window');

DROP TABLE IF EXISTS ipbanned;
CREATE TABLE `ipbanned` (
  `idip` double NOT NULL AUTO_INCREMENT COMMENT ' رقم الطرد',
  `ipStart` varchar(15) NOT NULL COMMENT 'بداية الايبي',
  `ipEnd` varchar(15) NOT NULL COMMENT 'نهاية الايبي',
  `reason` varchar(256) NOT NULL COMMENT 'السبب',
  `date` datetime NOT NULL COMMENT 'التاريخ',
  PRIMARY KEY (`idip`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='طرد الزوار المزعجين';

DROP TABLE IF EXISTS languages;
CREATE TABLE `languages` (
  `IdLang` varchar(11) NOT NULL COMMENT 'رقم اللغة',
  `LangName` varchar(15) NOT NULL COMMENT 'اسم اللغة',
  `Hits` varchar(7) NOT NULL COMMENT 'احصائيات',
  `Deleted` varchar(1) NOT NULL COMMENT 'هل اللغة محذوفة؟',
  UNIQUE KEY `IdLang` (`IdLang`),
  UNIQUE KEY `LangName` (`LangName`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='اللغات';

INSERT INTO `languages` VALUES
('20070000001', 'Arabic', '390', '0'),
('20070000002', 'English', '31', '0'),
('20140000000', 'Deutsch', '1', '0');

DROP TABLE IF EXISTS layersmenu;
CREATE TABLE `layersmenu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '1',
  `text` text /*!40101 CHARACTER SET utf8 */,
  `href` text /*!40101 CHARACTER SET utf8 */,
  `title` text /*!40101 CHARACTER SET utf8 */,
  `icon` text /*!40101 CHARACTER SET utf8 */,
  `target` text /*!40101 CHARACTER SET utf8 */,
  `orderfield` int(11) DEFAULT '0',
  `expanded` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=311 /*!40101 DEFAULT CHARSET=latin1 */;

INSERT INTO `layersmenu` VALUES
(10, 1, 'Home Page', 'Prog-pages.pt', 'Home Page', 'kfm_home.png', '', 30, 0);

DROP TABLE IF EXISTS layersmenulang;
CREATE TABLE `layersmenulang` (
  `language` varchar(15) /*!40101 CHARACTER SET utf8 */ NOT NULL,
  `id` int(11) NOT NULL,
  `text` text /*!40101 CHARACTER SET utf8 */,
  `title` text /*!40101 CHARACTER SET utf8 */,
  PRIMARY KEY (`language`,`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=latin1 */;

INSERT INTO `layersmenulang` VALUES
('Arabic', 10, 'الصفحة الرئيسية', 'عنوان الرئيسية'),
('English', 10, ' Home Page', 'Home Page');

DROP TABLE IF EXISTS letters;
CREATE TABLE `letters` (
  `idLetter` varchar(11) /*!40101 CHARACTER SET utf8 */ NOT NULL COMMENT 'رقم الرسالة',
  `LatterName` varchar(100) /*!40101 CHARACTER SET utf8 */ NOT NULL COMMENT 'اسم الرسالة',
  `Deleted` varchar(1) /*!40101 CHARACTER SET utf8 */ NOT NULL COMMENT 'هل هو محذوف؟',
  PRIMARY KEY (`idLetter`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_estonian_ci */ COMMENT='الرسائل النموذجية';

DROP TABLE IF EXISTS letterslang;
CREATE TABLE `letterslang` (
  `idLetter` varchar(11) NOT NULL COMMENT 'رقم الرسالة',
  `IdLang` varchar(11) NOT NULL COMMENT 'رقم اللغة',
  `TitleLetter` varchar(256) NOT NULL COMMENT 'عنوان الرسالة',
  `BodyLetter` longtext NOT NULL COMMENT 'الرسالة'
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='رسائل نموذجية';

DROP TABLE IF EXISTS mainmenu;
CREATE TABLE `mainmenu` (
  `IdMM` varchar(11) NOT NULL COMMENT 'رقم العنصر في الائحة',
  `Link` varchar(256) NOT NULL COMMENT 'الرابط',
  `Target` varchar(256) NOT NULL COMMENT 'وجهة النك',
  `Order` int(2) NOT NULL COMMENT 'ترتيبه من الاعلى',
  `External` varchar(1) NOT NULL COMMENT 'هل هذا الرابط خارجي؟',
  `IdPage` varchar(11) NOT NULL COMMENT 'رقم الصفحة المرتبطة بها ',
  UNIQUE KEY `IdMM` (`IdMM`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='عناصر الائحة الرئيسية';

INSERT INTO `mainmenu` VALUES
('20100000000', 'Prog-pages_pagenbr-1_Lang-English_nl-1.pt', '', 1, '0', '20100000001'),
('20140000000', 'http://localhost/phptransformer/Prog-pages_pagenbr-2_Lang-Arabic_nl-1.pt', '', 2, '0', '20140000000');

DROP TABLE IF EXISTS marqlang;
CREATE TABLE `marqlang` (
  `idmarque` varchar(11) NOT NULL COMMENT 'رقم الخبر',
  `idLang` varchar(11) NOT NULL COMMENT 'رقم اللغة',
  `Message` varchar(150) NOT NULL COMMENT 'الرسالة',
  UNIQUE KEY `idmarque` (`idmarque`,`idLang`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='شريط الاخبار حسب اللغة';

INSERT INTO `marqlang` VALUES
('20140000000', '20070000001', 'ياهووووووووووووووو'),
('20140000000', '20070000002', 'yahooooooooo'),
('20140000001', '20070000001', 'يسبسيبس يبيسبيسب'),
('20140000001', '20070000002', 'سشيسشيسشي');

DROP TABLE IF EXISTS marques;
CREATE TABLE `marques` (
  `idMarque` varchar(11) NOT NULL COMMENT 'رقم الخبر ',
  `Link` varchar(256) NOT NULL COMMENT 'الرابط',
  `StartDate` datetime NOT NULL COMMENT 'تاريخ البدء',
  `EndDate` datetime NOT NULL COMMENT 'تاريخ الانتهاء',
  `Deleted` varchar(1) NOT NULL COMMENT 'هل الخبر محذوف؟',
  `IdNews` varchar(11) NOT NULL,
  UNIQUE KEY `idMarque` (`idMarque`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='شريط الاخبار';

INSERT INTO `marques` VALUES
('20140000000', 'http://yahoo.com', '2014-09-22 14:56:56', '2014-09-26 14:56:58', '', ''),
('20140000001', 'http://localhost/phptransformer/Prog-news_ns-details_idnews-20140000000.pt', '2014-09-23 12:57:54', '2014-09-29 12:57:54', '', '20140000000');

DROP TABLE IF EXISTS menlang;
CREATE TABLE `menlang` (
  `idMM` varchar(11) NOT NULL COMMENT 'رقم العنصر في الائحة',
  `IdLang` varchar(11) NOT NULL COMMENT 'رقم اللغة',
  `TitleElement` varchar(35) NOT NULL COMMENT 'اسم العنصر بهذه اللغة',
  UNIQUE KEY `idMM` (`idMM`,`IdLang`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='اسماء عناصر الائحة الرئيسية حسب ?';

INSERT INTO `menlang` VALUES
('20100000000', '20070000001', 'الصفحة الأولى'),
('20100000000', '20070000002', 'Page One'),
('20140000000', '20070000001', 'يثبثص صصثيثص'),
('20140000000', '20070000002', 'dscfdf wef e f');

DROP TABLE IF EXISTS moderators;
CREATE TABLE `moderators` (
  `GroupId` varchar(11) NOT NULL COMMENT 'رقم المجموعة',
  `ObjectId` varchar(11) NOT NULL COMMENT 'رقم العنصر',
  `Permission` varchar(1) NOT NULL COMMENT 'الصلاحية',
  UNIQUE KEY `GroupId` (`GroupId`,`ObjectId`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='الاشراف';

INSERT INTO `moderators` VALUES
('200700000-1', '20110000000', '1'),
('200700000-1', '20110000003', '1'),
('20070000001', '20110000003', '1'),
('20070000000', '20110000003', '1'),
('20070000000', '20070000001', '1'),
('20070000001', '20070000001', '1'),
('200700000-1', '20070000001', '1');

DROP TABLE IF EXISTS news;
CREATE TABLE `news` (
  `IdNews` varchar(11) NOT NULL COMMENT 'رقم الخبر',
  `IdUserName` varchar(11) NOT NULL COMMENT 'رقم الكاتب',
  `Date` datetime NOT NULL COMMENT 'التاريخ',
  `Active` varchar(1) NOT NULL COMMENT 'نشط نعم او لا',
  `Hits` bigint(20) NOT NULL COMMENT 'زيارة',
  `NewsPic` text NOT NULL COMMENT 'صورة للخبر',
  `Deleted` varchar(1) NOT NULL COMMENT 'هل الخبر محذوف ؟',
  `active_by` varchar(11) NOT NULL,
  `del_by` varchar(11) NOT NULL,
  `location` text NOT NULL COMMENT 'geo location x,y',
  `uuid` text,
  PRIMARY KEY (`IdNews`),
  UNIQUE KEY `IdNews` (`IdNews`),
  KEY `Deleted` (`Deleted`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='الاخبار';

DROP TABLE IF EXISTS news_report;
CREATE TABLE `news_report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_news` varchar(11) NOT NULL,
  `nickname` varchar(20) NOT NULL,
  `time_sent` datetime NOT NULL,
  `time_read` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS news_subscription;
CREATE TABLE `news_subscription` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(11) NOT NULL,
  `cat_id` varchar(11) NOT NULL COMMENT 'المجموعة الاخبارية',
  `only_urgent` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='الاخبار التي ستظهر للمستخدم على تطبيق الهاتف';

DROP TABLE IF EXISTS newscategoies;
CREATE TABLE `newscategoies` (
  `IdNews` varchar(11) NOT NULL COMMENT 'رقمم الخبر',
  `IdCat` varchar(11) NOT NULL COMMENT 'رقم المجموعة',
  UNIQUE KEY `IdNews` (`IdNews`,`IdCat`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='ربط الخبر بمجموعة';

INSERT INTO `newscategoies` VALUES
('20140000000', '20100000000');

DROP TABLE IF EXISTS newscomment;
CREATE TABLE `newscomment` (
  `IdNews` varchar(11) NOT NULL COMMENT 'رقم الخبر',
  `CommentTitle` varchar(100) NOT NULL COMMENT 'عنوان التعليق',
  `UserId` varchar(11) NOT NULL COMMENT 'رقم المستخدم',
  `cc` varchar(3) NOT NULL COMMENT 'كود البلد',
  `CommentDate` datetime NOT NULL COMMENT 'تاريخ التعليق',
  `theComment` varchar(500) NOT NULL COMMENT 'نص التعليق',
  `idComment` varchar(11) NOT NULL COMMENT 'رقم التعليق',
  PRIMARY KEY (`idComment`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='تعليقات على الخبر';

DROP TABLE IF EXISTS newslang;
CREATE TABLE `newslang` (
  `IdLang` varchar(11) NOT NULL COMMENT 'رقمم اللغة',
  `IdNews` varchar(11) NOT NULL COMMENT 'رقم الخبر',
  `Tilte` varchar(256) DEFAULT NULL,
  `SubTitle` varchar(35) NOT NULL COMMENT 'العنوان الفرعي للخبر',
  `Breif` text NOT NULL COMMENT 'مختصر الخبر',
  `FullMessage` longtext NOT NULL COMMENT 'الخبر كاملا',
  `Note` varchar(200) NOT NULL COMMENT 'ملاحظة',
  PRIMARY KEY (`IdLang`,`IdNews`),
  KEY `Tilte` (`Tilte`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='الاخبار حسب اللغة';

INSERT INTO `newslang` VALUES
('20070000001', '20140000000', 'يسبسيبس يبيسبيسب', 'يسبيسبيسب ي صس', 'شسي سشيسشي سشي شسي', 'شسي شسي سشي سيءؤرسي شسي سشي', ''),
('20070000002', '20140000000', 'سشيسشيسشي', '', 'شسيشسي', 'شسيسشي', '');

DROP TABLE IF EXISTS notification;
CREATE TABLE `notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` varchar(11) NOT NULL,
  `id_news_group` varchar(11) NOT NULL,
  `only_urgent` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS objects;
CREATE TABLE `objects` (
  `ObjectId` varchar(11) NOT NULL COMMENT 'رقم العنصر',
  `ObjectName` varchar(35) NOT NULL COMMENT 'اسم العنصر',
  UNIQUE KEY `ObjectId` (`ObjectId`,`ObjectName`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='عناصر يتم التحكم بالوصول اليها ه?';

INSERT INTO `objects` VALUES
('20100000001', '{PageNumber} 1'),
('20140000000', '{PageNumber} 2');

DROP TABLE IF EXISTS oldstatistics;
CREATE TABLE `oldstatistics` (
  `MonthDate` varchar(8) NOT NULL COMMENT 'الشهر و السنة',
  `IPNbr` varchar(15) NOT NULL COMMENT 'ايبي بلد الزيارة',
  `Hits` varchar(7) NOT NULL COMMENT 'عدد الزيارات'
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='في الاحصاءات للاشهرو السنوات الق';

DROP TABLE IF EXISTS opstatistics;
CREATE TABLE `opstatistics` (
  `MSIE` varchar(7) NOT NULL COMMENT 'انترنت اكسبلورر',
  `Opera` varchar(7) NOT NULL COMMENT 'اوبرا',
  `Konqueror` varchar(7) NOT NULL COMMENT 'كونكيور',
  `Netscape` varchar(7) NOT NULL COMMENT 'نتسكايب',
  `FireFox` varchar(7) NOT NULL COMMENT 'فايرفوكس',
  `Bot` varchar(7) NOT NULL COMMENT 'بوت',
  `Windows` varchar(7) NOT NULL COMMENT 'زيندوز',
  `Linux` varchar(7) NOT NULL COMMENT 'لينكس',
  `Mac` varchar(7) NOT NULL COMMENT 'ماكنتوش',
  `FreeBsd` varchar(7) NOT NULL COMMENT 'فري باسدي',
  `Other` varchar(7) NOT NULL COMMENT 'اخر'
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='مستعرضات و انظمة تشغيل الزوار';

INSERT INTO `opstatistics` VALUES
('1', '1', '1', '1', '4', '1', '1', '5', '1', '1', '1');

DROP TABLE IF EXISTS pagelang;
CREATE TABLE `pagelang` (
  `IdPage` varchar(11) NOT NULL COMMENT 'رقم الريكورد',
  `IdLang` varchar(11) NOT NULL COMMENT 'رقم اللغة',
  `PageTitle` varchar(256) NOT NULL COMMENT 'عنوان الصفحة',
  `Content` longtext NOT NULL COMMENT 'محتوى الصفحة',
  PRIMARY KEY (`IdPage`,`IdLang`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `pagelang` VALUES
('20100000001', '20070000001', 'عنوان الصفحة الأولى', 'الموقع  قيد الانشاء  <div>ضصيصسيصض بثصبثصب</div>'),
('20100000001', '20070000002', 'Page Title', 'web site under construction'),
('20140000000', '20070000001', 'يثبثص صصثيثص', 'صصيصضيثصضي'),
('20140000000', '20070000002', 'dscfdf wef e f', 'few rer wer we wr we r');

DROP TABLE IF EXISTS pages;
CREATE TABLE `pages` (
  `IdPage` varchar(11) NOT NULL COMMENT 'رقم الريكورد',
  `PageNbr` bigint(11) DEFAULT NULL,
  `ObjectId` varchar(11) NOT NULL COMMENT 'رقم العنصر للصلاحيات',
  `Hits` double NOT NULL COMMENT 'عدد الزيارات',
  `Deleted` varchar(1) NOT NULL COMMENT 'هل هذه الصفحة محذوفة ؟',
  PRIMARY KEY (`IdPage`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `pages` VALUES
('20100000001', 1, '', '6', '0'),
('20140000000', 2, '20140000000', '1', '0');

DROP TABLE IF EXISTS params;
CREATE TABLE `params` (
  `MainPrograms` varchar(15) NOT NULL COMMENT 'البرنامج الافتراضي',
  `DefaultLang` varchar(15) NOT NULL COMMENT 'اللغة الافتراضية',
  `DefaultThem` varchar(15) NOT NULL COMMENT 'الشكل الافتراضي',
  `AutoLang` varchar(1) NOT NULL COMMENT 'استعمال خيار فحص اللغة الاتوماتي',
  `ConvertAt` varchar(1) NOT NULL COMMENT 'تحويل @الى صورة',
  `ExternalLinks` varchar(1) NOT NULL COMMENT 'السماح بالروابط الخارجية',
  `UseRew` varchar(1) NOT NULL COMMENT 'استعمال url rew',
  `CookieAge` varchar(15) NOT NULL COMMENT 'عمر الكوكيز الافتراضي',
  `IsOpen` varchar(1) NOT NULL COMMENT 'هل الموقع مفتوح نعم او لا',
  `DateGmt` varchar(3) NOT NULL COMMENT 'وقت الموقع بالنسبة لغرينتش',
  `ViewTopCont` varchar(1) NOT NULL COMMENT 'مشاهدة البلوكات في البرنامج الافتراضي',
  `ViewMarqueeCont` varchar(1) NOT NULL COMMENT 'مشاهدة البلوكات في البرنامج الافتراضي',
  `ViewMenuCont` varchar(1) NOT NULL COMMENT 'مشاهدة البلوكات في البرنامج الافتراضي',
  `ViewMainCont` varchar(1) NOT NULL COMMENT 'مشاهدة البلوكات في البرنامج الافتراضي',
  `ViewSecCont` varchar(1) NOT NULL COMMENT 'مشاهدة البلوكات في البرنامج الافتراضي',
  `ViewFootCont` varchar(1) NOT NULL COMMENT 'مشاهدة البلوكات في البرنامج الافتراضي',
  `ViewProgCont` varchar(1) NOT NULL COMMENT 'مشاهدة البلوكات في البرنامج الافتراضي',
  `OpenRegister` varchar(1) NOT NULL COMMENT 'الموقع سامح لتسجيل اعضاء جدد او لا',
  `GeoIpService` varchar(255) NOT NULL COMMENT 'الموقع الذي سيقدم خدمة تحديد بلد الايبي المتصل بالموقع',
  `AdminRegOk` varchar(1) NOT NULL COMMENT 'يجب ان يوافق المدير على تفعيل تسجيل الاعضاء الجدد',
  `MaxNbrPost` varchar(2) NOT NULL COMMENT 'العدد الاقصى لمحاولة ارسال معلومات خطأ',
  `DefaulPageNbr` varchar(3) NOT NULL COMMENT 'رقم الصفحة الافتراضية لبرنام الصفحات',
  `NewsMaxNbr` varchar(3) NOT NULL COMMENT 'العدد الاقصى للاخبار في صفحة الاخبار',
  `FloodSec` varchar(5) NOT NULL COMMENT 'عدد الثواني بين طلب كل صفحة من نفس المستخدم',
  `GuestCanWrite` varchar(1) NOT NULL COMMENT 'هل يسمح للزوار بالمشاركة دون تسجيل',
  `RobotAdmin` varchar(1) NOT NULL COMMENT 'استعمال المدير الالي',
  `MailList` varchar(11) NOT NULL COMMENT 'عدد الاعضاء الذين سيرسلهم لهم اخر بريد',
  `License` text NOT NULL COMMENT 'مفتاح الترخيص',
  `LastProg` varchar(35) NOT NULL COMMENT 'اخر برنامج تمت ادارته من لوحة تحكم المدير',
  `LastBlock` varchar(35) NOT NULL COMMENT 'اخر بلوك تمت ادارته من لوحة تحكم المدير',
  `EmailMethode` varchar(35) NOT NULL COMMENT 'smtp or sendmail',
  `CacheEnabled` int(1) NOT NULL,
  `TimeCache` int(100) NOT NULL,
  `IgnoreList` longtext NOT NULL,
  `WebSiteFullName` text NOT NULL,
  `GoogleCode` varchar(26) NOT NULL COMMENT 'Google analytics pageTracker ',
  `EnableStatistics` tinyint(1) NOT NULL COMMENT 'هل نظام الاحصائيات مفعل',
  `LastChekUpdate` datetime NOT NULL COMMENT 'آخر مرة تم فيها التحديث',
  `UpdateAvailble` float NOT NULL COMMENT 'رقم الاصدار المتوفر',
  `UpdateDesc` text NOT NULL COMMENT 'شرح التحديث الجديد',
  `UpdateName` text NOT NULL COMMENT 'اسم الاصدارة الجديدة',
  `android_key` text NOT NULL,
  `apple_key` text NOT NULL,
  `awsAccessKey` varchar(50) NOT NULL COMMENT 'Amazon cloud access key',
  `awsSecretKey` varchar(100) NOT NULL COMMENT 'amazon cloud secret key',
  `youtube_api_key` varchar(100) NOT NULL,
  `youtube_username` varchar(100) NOT NULL,
  `youtube_password` varchar(100) NOT NULL,
  PRIMARY KEY (`MainPrograms`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='خصائص الوقع الافتراضية';

INSERT INTO `params` VALUES
('news', 'Arabic', 'Default', '0', '1', '1', '1', 'Month', '1', '2', '1', '1', '1', '1', '1', '1', '1', '1', '//phptransformer.com/GeoIpDectecter/index.php?ip=', '0', '5', '1', '10', '0.06', '1', '0', '6', '', 'news', 'Pool', 'sendmail', 0, 86400, '', 'هذا موقعي الرائع', '', 1, '2014-09-23 10:49:16', '0', '', '', '', '', '', '', '', '', '');

DROP TABLE IF EXISTS plugins;
CREATE TABLE `plugins` (
  `id` varchar(11) NOT NULL COMMENT 'رقم الاضافة',
  `name` varchar(1024) NOT NULL COMMENT 'اسم الاضافة'
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='جدول الاضافات المفعلة';

DROP TABLE IF EXISTS poolchoices;
CREATE TABLE `poolchoices` (
  `idpc` varchar(11) NOT NULL COMMENT 'رقم الخيار',
  `idpt` varchar(11) NOT NULL COMMENT 'رقم التصويت',
  `cheked` varchar(1) NOT NULL COMMENT 'هل هو معلم',
  PRIMARY KEY (`idpc`,`idpt`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='خيارت التصويت';

INSERT INTO `poolchoices` VALUES
('20100000000', '20100000000', '0'),
('20100000001', '20100000000', '1'),
('20100000002', '20100000000', '0'),
('20100000003', '20100000000', '0');

DROP TABLE IF EXISTS poollangchoices;
CREATE TABLE `poollangchoices` (
  `IdLang` varchar(11) NOT NULL COMMENT 'رقم اللغة',
  `idpc` varchar(11) NOT NULL COMMENT 'رقم خيار التصويت',
  `Idpt` varchar(11) NOT NULL COMMENT 'رقم عنوان الخيار',
  `Choise` varchar(100) NOT NULL COMMENT 'الخيار بهذه اللغة',
  PRIMARY KEY (`IdLang`,`idpc`,`Idpt`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='خيارات التصويت بلغة معينة';

INSERT INTO `poollangchoices` VALUES
('20070000001', '20100000000', '20100000000', 'سعر قليل أو مجاني'),
('20070000001', '20100000001', '20100000000', 'حر مفتوح المصدر'),
('20070000001', '20100000002', '20100000000', 'سهولة استعماله'),
('20070000001', '20100000003', '20100000000', 'إنتشاره بشكل واسع'),
('20070000002', '20100000000', '20100000000', 'low cost or Free'),
('20070000002', '20100000001', '20100000000', 'Free Open source'),
('20070000002', '20100000002', '20100000000', 'Easy of use'),
('20070000002', '20100000003', '20100000000', 'Spread widely');

DROP TABLE IF EXISTS poollangtitles;
CREATE TABLE `poollangtitles` (
  `IdLang` varchar(11) NOT NULL COMMENT 'رقم اللغة',
  `Idpt` varchar(11) NOT NULL COMMENT 'رقم العنوان',
  `Title` varchar(100) NOT NULL COMMENT 'العنوان بهذه اللغة',
  PRIMARY KEY (`IdLang`,`Idpt`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='نص عنوان باللغات';

INSERT INTO `poollangtitles` VALUES
('20070000001', '20100000000', 'ماالذي يؤثر على اختيارك لبرنامج موقعك ؟'),
('20070000002', '20100000000', 'What affect the decision to choose your website program?');

DROP TABLE IF EXISTS pooltitle;
CREATE TABLE `pooltitle` (
  `Idpt` varchar(11) NOT NULL COMMENT 'رقم التصويت',
  `poolstart` datetime NOT NULL COMMENT 'تاريخ بدء التصويت',
  `poolend` datetime NOT NULL COMMENT 'تاريخ نهاية التصويت',
  `multichoice` varchar(1) NOT NULL COMMENT 'هل يسمح بتعدد الخيارات',
  `published` varchar(1) NOT NULL COMMENT 'هل مجهز للنشر',
  `lastpol` varchar(1) NOT NULL COMMENT 'هل هو ىخر تصويت',
  `Deleted` varchar(1) NOT NULL COMMENT 'هل التصويت محذوف؟',
  PRIMARY KEY (`Idpt`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='التصويتات';

INSERT INTO `pooltitle` VALUES
('20100000000', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', '1', '1', '');

DROP TABLE IF EXISTS poolusers;
CREATE TABLE `poolusers` (
  `UserId` varchar(11) NOT NULL COMMENT 'رقم المستخدم',
  `Idpt` varchar(11) NOT NULL COMMENT 'رقم عنوان التصويت',
  `idpc` varchar(11) NOT NULL COMMENT 'رقم الخيار المصوت له',
  `IpPool` varchar(15) NOT NULL COMMENT 'رقم ايبي التصويت',
  `Comment` varchar(250) NOT NULL COMMENT 'تعليق المستخدم'
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='تصويت المستخدمين';

DROP TABLE IF EXISTS programs;
CREATE TABLE `programs` (
  `IdProgram` varchar(11) NOT NULL COMMENT 'رقم البرنامج',
  `ProgramName` varchar(35) NOT NULL COMMENT 'اسم البرنامج',
  `Permission` varchar(1) NOT NULL COMMENT 'صلاحية للجميع ',
  `ViewTopCont` varchar(1) NOT NULL COMMENT 'مشاهدة هذا الـ container 1 نعم 0 لا',
  `ViewMarqueeCont` varchar(1) NOT NULL COMMENT 'مشاهدة هذا الـ container 1 نعم 0 لا',
  `ViewMenuCont` varchar(1) NOT NULL COMMENT 'مشاهدة هذا الـ container 1 نعم 0 لا',
  `ViewMainCont` varchar(1) NOT NULL COMMENT 'مشاهدة هذا الـ container 1 نعم 0 لا',
  `ViewSecCont` varchar(1) NOT NULL COMMENT 'مشاهدة هذا الـ container 1 نعم 0 لا',
  `ViewFootCont` varchar(1) NOT NULL COMMENT 'مشاهدة هذا الـ container 1 نعم 0 لا',
  `ViewProgCont` varchar(1) NOT NULL COMMENT 'مشاهدة هذا الـ container 1 نعم 0 لا',
  `ObjectId` varchar(11) NOT NULL COMMENT 'رقمه المرتبط بالسيكيوريتي',
  `Hits` double NOT NULL DEFAULT '0' COMMENT 'عدد المشاهدات',
  `Deleted` varchar(2) NOT NULL COMMENT 'محذوف الى سلة المحذوفات؟',
  `License` text NOT NULL COMMENT 'مفتاح الترخيص',
  `cached` int(1) NOT NULL,
  `cachetime` int(100) NOT NULL COMMENT 'وقت الحفظ',
  `LastChekUpdate` datetime NOT NULL COMMENT 'آخر مرة تم فيها التحديث',
  `UpdateAvailble` float NOT NULL COMMENT 'رقم الاصدار المتوفر',
  `UpdateDesc` text NOT NULL COMMENT 'شرح التحديث الجديد',
  UNIQUE KEY `IdProgram` (`IdProgram`,`ProgramName`),
  UNIQUE KEY `ProgramName` (`ProgramName`),
  UNIQUE KEY `ProgramName_2` (`ProgramName`),
  UNIQUE KEY `ProgramName_3` (`ProgramName`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `programs` VALUES
('20070000000', 'pages', '1', '1', '1', '1', '1', '1', '1', '1', '20070000000', '7', '0', '', 1, 0, '0000-00-00 00:00:00', '0', ''),
('20070000000', 'home', '1', '1', '1', '1', '1', '1', '1', '1', '20070000000', '10', '0', '', 1, 0, '0000-00-00 00:00:00', '0', ''),
('20070000001', 'account', '1', '1', '1', '1', '1', '1', '1', '1', '20070000001', '2', '0', '', 0, 0, '0000-00-00 00:00:00', '0', ''),
('20070000003', 'tellfriend', '1', '1', '1', '1', '1', '1', '1', '1', '20070000003', '1', '0', '', 0, 0, '0000-00-00 00:00:00', '0', ''),
('20070000004', 'pool', '1', '1', '1', '1', '1', '1', '1', '1', '20070000009', '1', '0', '', 0, 0, '0000-00-00 00:00:00', '0', ''),
('20070000005', 'usercp', '1', '1', '1', '1', '1', '1', '1', '1', '20070000010', '1', '0', '', 0, 0, '0000-00-00 00:00:00', '0', ''),
('20070000007', 'news', '1', '1', '1', '1', '1', '1', '1', '1', '20070000001', '28', '0', '', 0, 0, '0000-00-00 00:00:00', '0', ''),
('20070000008', 'ads', '1', '1', '1', '1', '1', '1', '1', '1', '20070000012', '1', '0', '', 0, 0, '0000-00-00 00:00:00', '0', ''),
('20070000009', 'exlink', '1', '1', '1', '1', '1', '1', '1', '1', '20070000016', '1', '0', '', 0, 0, '0000-00-00 00:00:00', '0', ''),
('20080000012', 'contactus', '1', '1', '1', '1', '1', '1', '1', '1', '20080000018', '1', '0', '', 0, 0, '0000-00-00 00:00:00', '0', ''),
('20080000020', 'rss', '1', '0', '0', '0', '0', '0', '0', '1', '20080000029', '1', '0', '', 0, 0, '0000-00-00 00:00:00', '0', ''),
('20110000001', 'gallery', '1', '1', '1', '1', '1', '1', '1', '1', '20110000003', '30', '0', '', 0, 0, '0000-00-00 00:00:00', '0', '');

DROP TABLE IF EXISTS pt_menu;
CREATE TABLE `pt_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '1',
  `href` text,
  `icon` text,
  `target` text,
  `orderfield` int(11) DEFAULT '0',
  `expanded` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS pt_menu_lang;
CREATE TABLE `pt_menu_lang` (
  `IdLang` varchar(11) NOT NULL,
  `id` int(11) NOT NULL,
  `text` text,
  `title` text,
  PRIMARY KEY (`IdLang`,`id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS screens;
CREATE TABLE `screens` (
  `ScreenXY` varchar(10) NOT NULL COMMENT 'ارتفاع و عرض الشاشة',
  `Hits` bigint(7) NOT NULL COMMENT 'عدد الشاشات'
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='احصائيات شاشات الزوار';

INSERT INTO `screens` VALUES
('Anknow', 2),
('1024x768', 1),
('1440x900', 4),
('1600x1200', 1),
('1264x900', 1),
('1152x864', 1),
('1536x1152', 1);

DROP TABLE IF EXISTS themes;
CREATE TABLE `themes` (
  `ThemeName` varchar(100) NOT NULL COMMENT 'اسم مجلد الشكل',
  `Active` varchar(1) NOT NULL COMMENT '  او محذوف نشط او لا',
  `LastChekUpdate` datetime NOT NULL COMMENT 'آخر مرة تم فيها التحديث',
  `UpdateAvailble` float NOT NULL COMMENT 'رقم الاصدار المتوفر',
  `License` text NOT NULL COMMENT 'رقم ترخيص الدعم الفني',
  `UpdateDesc` text NOT NULL COMMENT 'شرح التحديث الجديد',
  PRIMARY KEY (`ThemeName`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `themes` VALUES
('Default', '1', '0000-00-00 00:00:00', '0', '', '');

DROP TABLE IF EXISTS thm_default_caption;
CREATE TABLE `thm_default_caption` (
  `id` varchar(11) NOT NULL COMMENT 'رقم الصورة',
  `id_lang` varchar(11) NOT NULL COMMENT 'رقم اللغة',
  `caption` text NOT NULL COMMENT 'النص الظاهر بهذه اللغة',
  PRIMARY KEY (`id`,`id_lang`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='شرح صور السلايدر';

INSERT INTO `thm_default_caption` VALUES
('0', '20070000002', 'Ease to use'),
('1', '20070000002', 'Join our team'),
('0', '20070000001', 'سهل الإستعمال'),
('1', '20070000001', 'يمكنك أيضاً الإنضمام إلينا'),
('3', '20070000002', 'All you need to built your website in one program'),
('2', '20070000002', 'We are ready for any support and any help'),
('2', '20070000001', 'فريقنا جاهز لأي دعم وأي مساعدة'),
('3', '20070000001', 'كل ما تحتاجه لبناء موقعك في برنامج واحد'),
('4', '20070000002', 'Free and open source'),
('4', '20070000001', 'برنامج مجاني ومفتوح المصدر');

DROP TABLE IF EXISTS thm_default_slider;
CREATE TABLE `thm_default_slider` (
  `id` varchar(11) NOT NULL COMMENT 'رقم الصورة',
  `path` text NOT NULL COMMENT 'مسار الصورة',
  `href` text NOT NULL COMMENT 'الرابط',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='صور السلايدر';

INSERT INTO `thm_default_slider` VALUES
('0', 'Themes/Default/slider/img/easy.jpg', 'http://phptransformer.com/release/Prog-pages_pagenbr-4_nl-1.pt'),
('1', 'Themes/Default/slider/img/join.jpg', 'http://phptransformer.com/release/Prog-pages_pagenbr-10_nl-1.pt'),
('2', 'Themes/Default/slider/img/technical.jpg', 'http://phptransformer.com/release/Prog-hosting_hst-Support_nl-1.pt'),
('3', 'Themes/Default/slider/img/allin1.jpg', 'http://sourceforge.net/projects/phptransformer/'),
('4', 'Themes/Default/slider/img/free.jpg', 'http://www.gnu.org/licenses/agpl-3.0.html');

DROP TABLE IF EXISTS users;
CREATE TABLE `users` (
  `UserId` varchar(11) NOT NULL COMMENT 'رقم المستخدم',
  `GroupId` varchar(11) NOT NULL COMMENT 'رقم المجموعة التي ينتسب اليها',
  `TimeFormat` varchar(12) NOT NULL COMMENT 'رقم شكل اظهار الوقت',
  `UserName` varchar(20) NOT NULL COMMENT 'اسم المستخدم',
  `NickName` varchar(20) NOT NULL COMMENT 'الاسم المستعار',
  `ParentName` varchar(20) NOT NULL COMMENT 'اسم الوالد',
  `FamName` varchar(20) NOT NULL COMMENT 'اسم العائلة',
  `BirthDate` date NOT NULL COMMENT 'تاريخ الميلاد',
  `Sex` varchar(1) NOT NULL COMMENT 'الجنس',
  `Gmt` varchar(3) NOT NULL COMMENT 'وقته بالنسبة لغرينتش',
  `Contry` varchar(15) NOT NULL COMMENT 'البلد',
  `town` varchar(15) NOT NULL COMMENT 'البلدة او المدينة',
  `Rue` varchar(15) NOT NULL COMMENT 'الشارع',
  `AddDetails` varchar(35) NOT NULL COMMENT 'العنوان مفصل',
  `CodePostal` varchar(4) NOT NULL COMMENT 'صندوق البريد',
  `ZipCode` varchar(4) NOT NULL COMMENT 'الرمز البريدي',
  `PhoneNbr` varchar(20) NOT NULL COMMENT 'رقم الهاتف',
  `CellNbr` varchar(20) NOT NULL COMMENT 'رقم الموبايل',
  `PassWord` varchar(35) NOT NULL COMMENT 'كلمة السر',
  `LastLogin` datetime NOT NULL COMMENT 'اخر دخول',
  `LastIP` varchar(15) NOT NULL COMMENT 'اخر رقم ايبي دخل منه',
  `Hobies` varchar(15) NOT NULL COMMENT 'الهوايات',
  `Job` varchar(15) NOT NULL COMMENT 'الوظيفة',
  `Education` varchar(15) NOT NULL COMMENT 'التعليم',
  `PrefLang` varchar(15) NOT NULL COMMENT 'اللغة المفضلة',
  `PrefTime` varchar(12) NOT NULL COMMENT 'الوقت المفضل للاتصال بالمستخدم بين كذا و كذا',
  `CookieLife` varchar(8) NOT NULL COMMENT 'عمر الكوكيز',
  `UserPic` text NOT NULL COMMENT 'اسم ملف صورة المستخدم',
  `UserMail` varchar(50) NOT NULL COMMENT 'بريد المستخدم',
  `UserSite` varchar(50) NOT NULL COMMENT 'موقع المستخدم',
  `Banned` varchar(1) NOT NULL COMMENT 'مطرود نعم او لا',
  `PrefThem` varchar(15) NOT NULL COMMENT 'الشكل المفضل',
  `UserSign` text NOT NULL COMMENT 'توقيعه',
  `Points` int(11) NOT NULL DEFAULT '0' COMMENT 'نقاطه',
  `Active` varchar(1) NOT NULL COMMENT 'نشط نعم اولا',
  `RegDate` datetime NOT NULL COMMENT 'تاريخ تسجيله',
  `allowHtml` varchar(1) NOT NULL COMMENT 'سماح بكود html',
  `allowBBcode` varchar(1) NOT NULL COMMENT 'سماح بكود bbcode',
  `allowSmiles` varchar(1) NOT NULL COMMENT 'السماح بتعابير',
  `allowAvatar` varchar(1) NOT NULL COMMENT 'السماح بصورة رمزية',
  `ConfirmCode` varchar(35) NOT NULL COMMENT 'كود تاكيد الاشتراك',
  `Mailed` varchar(2) NOT NULL COMMENT 'هل تم ارسال رسالة له اخر مرة؟',
  `Deleted` varchar(1) NOT NULL COMMENT 'هل هو محذوف؟',
  `LastSession` varchar(35) NOT NULL,
  `android_id` text NOT NULL,
  `apple_id` text NOT NULL,
  `uuid` text COMMENT 'device unique id',
  `app_token` text NOT NULL COMMENT 'session number for mobile app',
  PRIMARY KEY (`UserId`),
  UNIQUE KEY `UserId` (`UserId`),
  UNIQUE KEY `NickName` (`NickName`),
  UNIQUE KEY `UserMail` (`UserMail`),
  KEY `NickName_2` (`NickName`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='اسماء المستخدمين للموقع';

INSERT INTO `users` VALUES
('20070000000', '20070000000', 'Y-m-d H:i:s', 'Guest', 'Guest', 'parent', 'family', '0000-00-00', '1', '+2', 'US', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 'd78b6f30225cdc811adfe8d4e7c9fd34', '2010-11-25 14:51:20', 'fe80::a998:ae3:', 'None', 'None', 'None', 'Arabic', '12:00-16:00', '8640', '', 'None', 'None', '0', 'Default', 'Guest', 1, '1', '0000-00-00 00:00:00', '0', '0', '0', '0', '', '1', '0', '96jlqqiqds24us569dkodr9hu0', '', '', NULL, ''),
('200700000-1', '200700000-1', 'Y-m-d H:i:s', 'admin', 'admin', 'admin', 'admin', '1900-05-10', '1', '+2', 'LB', 'beiruth', '', '', '', '', '', '', 'd78b6f30225cdc811adfe8d4e7c9fd34', '2014-09-23 13:20:36', 'fe80::a998:ae3:', 'Computer', 'Administrator', 'IT', 'Arabic', '12:00-16:00', '8640', 'images/avatars/mybrain.jpg', 'user@phptransformer.com', 'www.phptransformer.com', '0', 'Default', 'ADMINISTRATOR', 1, '1', '2007-05-10 13:48:47', '1', '1', '1', '1', '', '1', '0', 'b7b946f71ef84de793b14197450376f6', '', '', NULL, '');

DROP TABLE IF EXISTS userslog;
CREATE TABLE `userslog` (
  `NickName` varchar(15) NOT NULL COMMENT 'اسم المستخدم',
  `Gmt` datetime NOT NULL COMMENT 'الوقت حسب غرينتش',
  `IpNbr` varchar(15) NOT NULL COMMENT 'رقم الايبي',
  `SessionId` varchar(35) DEFAULT NULL,
  `FromPage` varchar(256) NOT NULL COMMENT 'الصفحة التي اتى منها',
  `CurrentPage` varchar(256) NOT NULL COMMENT 'الصفحة الحالية'
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ COMMENT='لوغ  دخول المستخدمين';

INSERT INTO `userslog` VALUES
('Guest', '2014-09-23 10:59:38', '127.0.0.1', 'ks0v00k1qkjf9ps99m5niuuf82', 'http://localhost/phptransformer/Prog-pages_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 10:59:38', '127.0.0.1', 'ks0v00k1qkjf9ps99m5niuuf82', 'http://localhost/phptransformer/Prog-pages_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 10:48:51', '127.0.0.1', 'ks0v00k1qkjf9ps99m5niuuf82', 'http://localhost/phptransformer/Prog-home_Lang-English_nl-1.pt', ''),
('Guest', '2014-09-23 10:48:51', '127.0.0.1', 'ks0v00k1qkjf9ps99m5niuuf82', 'http://localhost/phptransformer/Prog-home_Lang-English_nl-1.pt', ''),
('Guest', '2014-09-23 10:58:51', '127.0.0.1', 'ks0v00k1qkjf9ps99m5niuuf82', 'http://localhost/phptransformer/Prog-pages_Lang-English_nl-1.pt', ''),
('Guest', '2014-09-23 10:58:51', '127.0.0.1', 'ks0v00k1qkjf9ps99m5niuuf82', 'http://localhost/phptransformer/Prog-pages_Lang-English_nl-1.pt', ''),
('admin', '2014-09-23 11:07:26', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-home_Lang-English_nl-1.pt', ''),
('admin', '2014-09-23 11:07:26', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-home_Lang-English_nl-1.pt', ''),
('admin', '2014-09-23 11:15:20', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-news_Lang-Arabic_nl-1.pt', ''),
('admin', '2014-09-23 11:15:20', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-news_Lang-Arabic_nl-1.pt', ''),
('admin', '2014-09-23 11:20:37', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-news_Lang-Arabic_nl-1.pt', ''),
('admin', '2014-09-23 11:20:37', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-news_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 11:20:56', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-news_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 11:20:56', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-news_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 11:21:48', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-news_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 11:21:48', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-news_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 11:24:59', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-news_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 11:24:59', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-news_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 11:25:16', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-news_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 11:25:16', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-news_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 11:43:41', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-news_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 11:43:41', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-news_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 11:44:00', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-news_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 11:44:00', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-news_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 11:53:31', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-news_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 11:53:31', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-news_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 11:53:36', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/index.php?Prog=news&Lang=Arabic&nl=1', ''),
('Guest', '2014-09-23 11:53:36', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/index.php?Prog=news&Lang=Arabic&nl=1', ''),
('Guest', '2014-09-23 11:54:05', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-news_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 11:54:05', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-news_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:01:35', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-pages_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:01:35', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-pages_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:02:08', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-pages_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:02:08', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-pages_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:03:05', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-pages_pagenbr-2_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:03:05', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-pages_pagenbr-2_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:14:45', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-galley_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:14:45', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-galley_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:14:55', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-Galley_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:14:55', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-Galley_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:15:05', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-galley_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:15:05', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-galley_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:17:42', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-galley_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:17:42', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-galley_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:18:07', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-galley_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:18:07', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-galley_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:18:33', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-galley_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:18:33', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-galley_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:19:18', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:19:18', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:20:11', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:20:11', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:38:58', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:38:58', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:42:37', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:42:37', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:47:01', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:47:01', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:47:05', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_add-cmnt_galid-20140000000_title-Screenshot_from_2014-09-22_18:29:09_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:47:05', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_add-cmnt_galid-20140000000_title-Screenshot_from_2014-09-22_18:29:09_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:47:10', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_add-cmnt_galid-20140000000_title-Screenshot_from_2014-09-22_18:29:09_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:47:10', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_add-cmnt_galid-20140000000_title-Screenshot_from_2014-09-22_18:29:09_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:47:20', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_add-cmnt_galid-20140000000_title-Screenshot_from_2014-09-22_18:29:09_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:47:20', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_add-cmnt_galid-20140000000_title-Screenshot_from_2014-09-22_18:29:09_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:47:22', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_show-all_galid-20140000000_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:47:22', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_show-all_galid-20140000000_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:47:45', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_show-all_galid-_title-Screenshot_from_2014-09-22_18:29:09_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:47:45', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_show-all_galid-_title-Screenshot_from_2014-09-22_18:29:09_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:48:04', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_add-cmnt_galid-20140000000_title-Screenshot_from_2014-09-22_18:29:09_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:48:04', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_add-cmnt_galid-20140000000_title-Screenshot_from_2014-09-22_18:29:09_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:48:06', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_show-all_galid-20140000000_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:48:06', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_show-all_galid-20140000000_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:48:12', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_add-cmnt_galid-20140000000_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:48:12', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_add-cmnt_galid-20140000000_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:48:34', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_add-cmnt_galid-20140000000_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:48:34', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_add-cmnt_galid-20140000000_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:48:36', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_show-all_galid-20140000000_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:48:36', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_show-all_galid-20140000000_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:48:55', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_show-all_galid-_title-Screenshot_from_2014-09-22_18:29:09_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:48:55', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_show-all_galid-_title-Screenshot_from_2014-09-22_18:29:09_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:48:57', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_add-cmnt_galid-20140000001_title-%D9%87%D8%B0%D8%A7_%D8%B9%D9%86%D9%88%D8%A7%D9%86_%D8%A7%D9%84%D8%B5%D9%88%D8%B1%D8%A9_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:48:57', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_add-cmnt_galid-20140000001_title-%D9%87%D8%B0%D8%A7_%D8%B9%D9%86%D9%88%D8%A7%D9%86_%D8%A7%D9%84%D8%B5%D9%88%D8%B1%D8%A9_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:49:01', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_add-cmnt_galid-20140000001_title-%D9%87%D8%B0%D8%A7_%D8%B9%D9%86%D9%88%D8%A7%D9%86_%D8%A7%D9%84%D8%B5%D9%88%D8%B1%D8%A9_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:49:01', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_add-cmnt_galid-20140000001_title-%D9%87%D8%B0%D8%A7_%D8%B9%D9%86%D9%88%D8%A7%D9%86_%D8%A7%D9%84%D8%B5%D9%88%D8%B1%D8%A9_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:49:03', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_show-all_galid-20140000001_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:49:04', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_show-all_galid-20140000001_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:49:21', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_show-all_galid-20140000001_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:49:21', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_show-all_galid-20140000001_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:49:25', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_add-cmnt_galid-20140000001_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:49:25', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_add-cmnt_galid-20140000001_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:49:32', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_add-cmnt_galid-20140000001_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:49:32', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_add-cmnt_galid-20140000001_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:49:34', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_show-all_galid-20140000001_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:49:34', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_show-all_galid-20140000001_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:51:20', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_show-all_galid-20140000001_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:51:20', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_show-all_galid-20140000001_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:57:20', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_show-all_galid-20140000001_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:57:20', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_show-all_galid-20140000001_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:57:38', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_show-all_galid-20140000001_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:57:38', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_show-all_galid-20140000001_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:57:42', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_add-cmnt_galid-20140000001_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:57:42', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_add-cmnt_galid-20140000001_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:58:37', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_add-cmnt_galid-20140000001_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:58:37', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-gallery_add-cmnt_galid-20140000001_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:58:41', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-news_ns-details_idnews-20140000000.pt', ''),
('Guest', '2014-09-23 12:58:41', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-news_ns-details_idnews-20140000000.pt', ''),
('Guest', '2014-09-23 12:59:52', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-news_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 12:59:52', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-news_Lang-Arabic_nl-1.pt', ''),
('Guest', '2014-09-23 13:03:20', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-news_ns-details_idnews-20140000000.pt', ''),
('Guest', '2014-09-23 13:03:20', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-news_ns-details_idnews-20140000000.pt', ''),
('Guest', '2014-09-23 13:05:11', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-news_ns-details_idnews-20140000000.pt', ''),
('Guest', '2014-09-23 13:05:11', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-news_ns-details_idnews-20140000000.pt', ''),
('Guest', '2014-09-23 13:05:13', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-news_ns-details_idnews-20140000000_Lang-Deutsch.pt', ''),
('Guest', '2014-09-23 13:05:13', '127.0.0.1', 'rah8dnqvnpk7tdpk0a7tiggk92', 'http://localhost/phptransformer/Prog-news_ns-details_idnews-20140000000_Lang-Deutsch.pt', '');

